clear all; close all; clc;
number = 1;
[X,map] = imread(cat(2,'Database/videos/video',num2str(number)), 'GIF');
%%
focus = 20000;
R = 40;
thresh = 0.4;
th = 20;
num_rows = size(X,1);num_cols = size(X,2);
r_max = round(num_rows/5);
x0 = num_cols + th + 10;
y0 = num_rows + th + 10;
mean = 0;
c_mean = 0;
frames_with_ball = 0;
start_frame = 1;
restart = 1;
counts = [];
c_counts = [];
window = 6;
first_time_flag = 1;
f = fopen(cat(2,'Parameters/parameters',num2str(number),'.txt'),'w');
votes = zeros(num_cols,num_rows,ceil(r_max*sqrt(2)+3));

%%
for frame=1:size(X,4)
    votes(:) = 0;
    img = im2double(X(:,:,:,frame));
    canny_edges = edge(img,'canny',thresh);
%     if frame == 80
%         imshow(canny_edges)
%         figure
%     end
    %%
    edges_lin_index = find(canny_edges);
    for i=1:size(edges_lin_index,1)
        edge_x = floor(edges_lin_index(i)/num_rows) + 1;
        edge_y = edges_lin_index(i) - num_rows*(edge_x-1);
        if restart == 1 || (restart == 0 && (edge_y-y0) + (edge_x-x0) <= th)
            for j=max(edge_x - r_max,1):min(edge_x + r_max,num_cols)
                for k=max(edge_y - r_max,1):min(edge_y + r_max,num_rows)
                    radius = max(ceil(sqrt((edge_x - j)^2 + (edge_y - k)^2)),1);
                    votes(j,k,radius) = votes(j,k,radius) + 1;
                    votes(j,k,radius+1) = votes(j,k,radius+1) + 1;
                    if radius>1
                        votes(j,k,radius-1) = votes(j,k,radius-1) + 1;
                    end
                end
            end
        end
    end
    [c,i] = max(votes(:));
    r = floor(i/(num_cols*num_rows)) + 1;
    y0 = floor((i - num_cols*num_rows*(r-1))/num_cols) + 1;
    x0 = (i - num_cols*num_rows*(r-1)) - num_cols*(y0-1);
    z0 = R*focus/r;
    
    if c > 0.6*c_mean && r >= 0.75*mean && ((r <= 2*mean && mean>0) || mean==0)
        counts = cat(2,counts,r);
        c_counts = cat(2,c_counts,c);
        first_time_flag = 1;
        frames_with_ball = frames_with_ball + 1;
        if restart == 1
            restart = 0;
            start_frame = frames_with_ball;
        end
        
%         fprintf(f,'Included: %d %d %d %d %d\n',x0,y0,r,c,mean);
        
        fprintf(f,'%d %d %d\n',(x0-num_cols/2)*z0/focus,(y0-num_rows)*z0/focus,z0);
        if frames_with_ball > start_frame
            if frames_with_ball-start_frame >= window
                mean = sum(counts(frames_with_ball-(window-1):end))/window;
                c_mean = sum(c_counts(frames_with_ball-(window-1):end))/window;
            else
                mean = sum(counts(start_frame+1:end))/(size(counts,2)-start_frame);
                c_mean = sum(c_counts(start_frame+1:end))/(size(c_counts,2)-start_frame);
            end
        end
        
        imshow(uint8(255*img),map)
        viscircles([x0,y0],r,'EdgeColor',[0,0,0],'LineWidth',2.5)
        M(frame) = getframe();
%         figure
    else
        if first_time_flag == 1
            fprintf(f,'\n');
            first_time_flag = 0;
        end
        
%         fprintf(f,'Excluded: %d %d %d %d %d\n',x0,y0,r,c,mean);
        restart = 1;
        imshow(uint8(255*img),map)
        M(frame) = getframe();
%         figure
    end
end
fprintf(f,'\n');
fclose(f);
% movie2avi(M, 'tracked.avi','quality',100,'fps',35,'compression','Cinepak');
% close all

