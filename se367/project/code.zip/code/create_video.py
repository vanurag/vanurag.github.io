import sys, pygame,time, math, numpy, pickle
from images2gif import writeGif
pygame.init()
timer = pygame.time.Clock()

size = width, height = 860, 360
black = 0, 0, 0

screen = pygame.display.set_mode(size)

foreground = pygame.image.load("ball.gif")
fgRect = foreground.get_rect()

m_to_p = 111/0.35
f = 20000
R = 40

left_bound = 0
right_bound = width
bot_g = ((left_bound,0,1000),(left_bound,0,100000),(right_bound,0,100000),(right_bound,0,1000))
left_g = ((left_bound,0,1000),(left_bound,0,100000),(left_bound,-height,100000),(left_bound,-height,1000))
right_g = ((right_bound,0,1000),(right_bound,0,100000),(right_bound,-height,100000),(right_bound,-height,1000))

###### Parameters you can vary
switch = 1
video_number = '6'
x_g = width/2
y_g = -300
z_g = 200*m_to_p
y_shift = -height/4
x_shift = width/2

theta_x = math.pi/800
theta_y = 0#math.pi/300
theta_z = -math.pi/50

speed = [1.1*m_to_p, 0.7*m_to_p, -60*m_to_p]
acceleration = [0, 0.98*m_to_p, 0]
#######


Rx_G_1 = numpy.mat([[1,0,0],[0,math.cos(theta_x),-math.sin(theta_x)],\
          [0,math.sin(theta_x),math.cos(theta_x)]])
Ry_G_1 = numpy.mat([[math.cos(theta_y),0,math.sin(theta_y)],[0,1,0],\
          [-math.sin(theta_y),0,math.cos(theta_y)]])
Rz_G_1 = numpy.mat([[math.cos(theta_z),-math.sin(theta_z),0],\
          [math.sin(theta_z),math.cos(theta_z),0],[0,0,1]])

R_G_1 = Rx_G_1*Ry_G_1*Rz_G_1
O_G_1 = Rz_G_1*Ry_G_1*Rx_G_1*numpy.transpose(numpy.mat([-x_shift,-y_shift,0]))

dt = 0.033
frames = []

bot = []
left = []
right = []
for i in range(4):
    P1 = R_G_1*numpy.transpose(numpy.mat([bot_g[i][0],bot_g[i][1],bot_g[i][2]])) + O_G_1
    temp_bot = ()
    temp_bot = temp_bot + ( int(P1[0]*f/P1[2] + width/2) ,)
    temp_bot = temp_bot + ( int(P1[1]*f/P1[2] + height) ,)
    bot.append( temp_bot )

    P1 = R_G_1*numpy.transpose(numpy.mat([left_g[i][0],left_g[i][1],left_g[i][2]])) + O_G_1
    temp_left = ()
    temp_left = temp_left + ( int(P1[0]*f/P1[2] + width/2) ,)
    temp_left = temp_left + ( int(P1[1]*f/P1[2] + height) ,)
    left.append( temp_left )

    P1 = R_G_1*numpy.transpose(numpy.mat([right_g[i][0],right_g[i][1],right_g[i][2]])) + O_G_1
    temp_right = ()
    temp_right = temp_right + ( int(P1[0]*f/P1[2] + width/2) ,)
    temp_right = temp_right + ( int(P1[1]*f/P1[2] + height) ,)
    right.append( temp_right )


bot = tuple(bot)
left = tuple(left)
right = tuple(right)

for t in range(100):

    if x_g - R< left_bound:
        speed[0] = 0.95*math.fabs(speed[0])
    if x_g + R> right_bound:
        speed[0] = -0.95*math.fabs(speed[0])
##    if y_g - R < 0:
##        speed[1] = 0.95*math.fabs(speed[1])
    if y_g + R > 0:
        speed[1] = -0.9*math.fabs(speed[1])

    speed[0] += acceleration[0]*dt
    speed[1] += acceleration[1]*dt
    speed[2] += acceleration[2]*dt
    x_g += speed[0] * dt + 0.5*acceleration[0]*(dt**2)
    y_g += speed[1] * dt + 0.5*acceleration[1]*(dt**2)
    z_g += speed[2] * dt + 0.5*acceleration[2]*(dt**2)

    P1 = R_G_1*numpy.transpose(numpy.mat([x_g,y_g,z_g])) + O_G_1
    x = int(P1[0])
    y = int(P1[1])
    z = int(P1[2])

    x = (x*f/z)
    y = (y*f/z)

    fg_width = int(2*R*f/z)
    fg_height = int(2*R*f/z)

    foreground = pygame.transform.scale(foreground, (fg_width,fg_height))
    fgRect = foreground.get_rect()
    fgRect.centerx = int(x + width/2)
    fgRect.centery = int(y + height)
    if y_g + R > -2 and math.fabs(speed[1]) < 3:
        break
    
    screen.fill(black)
    pygame.draw.polygon(screen, (0,255,0), bot, 0)
    pygame.draw.polygon(screen, (153,76,0), left, 0)
    pygame.draw.polygon(screen, (153,76,0), right, 0)
    screen.blit(foreground, fgRect)
    foreground = pygame.image.load("ball.gif")
    pygame.display.flip()

    if switch == 1:
        array = pygame.surfarray.array3d(pygame.transform.rotate(screen, -90))
        array = array[::-1]
        frames.append(array)

    timer.tick(1/dt + 7)

if switch == 1:
    writeGif('Database/videos/video'+video_number+'.GIF', frames, duration=0.0268)
    f = open('Database/Parameters/ROT'+video_number+'.txt','w')
    for i in range(3):
        for j in range(3):
            f.write(str(R_G_1[i,j]) + ' ')
        f.write('\n')
    f.write('\n')

    for i in range(3):
        f.write(str(O_G_1[i,0]) + ' ')
        f.write('\n')
    f.close()


    
