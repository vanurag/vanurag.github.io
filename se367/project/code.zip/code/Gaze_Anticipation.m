clear all; close all; clc;
number = 6;
[X,map] = imread(cat(2,'Database/videos/video',num2str(number)), 'GIF');
%%
focus = 20000;
R = 40;
thresh = 0.4;
th = 20;
num_rows = size(X,1);num_cols = size(X,2);
r_max = round(num_rows/5);
x0 = num_cols + th + 10;
y0 = num_rows + th + 10;
mean = 0;
c_mean = 0;
frames_with_ball = 0;
start_frame = 1;
restart = 1;
counts = [];
c_counts = [];
window = 6;
first_time_flag = 1;
votes = zeros(num_cols,num_rows,ceil(r_max*sqrt(2)+3));

f2 = fopen(cat(2,'Database/parameters/ROT',num2str(number),'.txt'),'r');
Rot_Trans = fscanf(f2,'%f');
Rot = reshape(Rot_Trans(1:9,:),[3 size(Rot_Trans(1:9,:),1)/3])';
Translation = Rot_Trans(10:12,:);
fclose(f2);

dt = 0.033;
State = [0;0;0;0;0;0;0;0;0]; % initial state (location and velocity)
P_uncertainity = 1000*eye(9); % initial uncertainty
State_Transition_Matrix = [1,0,0,dt,0,0,(dt^2)/2,0,0;
                           0,1,0,0,dt,0,0,(dt^2)/2,0;
                           0,0,1,0,0,dt,0,0,(dt^2)/2;
                           0,0,0,1,0,0,dt,0,0;
                           0,0,0,0,1,0,0,dt,0;
                           0,0,0,0,0,1,0,0,dt;
                           0,0,0,0,0,0,1,0,0;
                           0,0,0,0,0,0,0,1,0;
                           0,0,0,0,0,0,0,0,1]; % next state function

F_bounce = eye(9);F_bounce(5,5) = -0.9;
F_side = eye(9);F_side(4,4) = -0.95;

% load('Learnt_Transition_Matrix','Learnt_Transition_Matrix');
% State_Transition_Matrix = Learnt_Transition_Matrix;
Q = 0.01*eye(9);
H = zeros(3,9);
H(1,1) = 1;H(2,2) = 1;H(3,3) = 1; % measurement function
R_noise = zeros(3,3); % measurement uncertainty

%%
for frame=1:70%size(X,4)
    votes(:) = 0;
    img = im2double(X(:,:,:,frame));
    canny_edges = edge(img,'canny',thresh);
%     if frame == 1
%         imshow(canny_edges)
%         figure
%     end
    %%
    edges_lin_index = find(canny_edges);
    for i=1:size(edges_lin_index,1)
        edge_x = floor(edges_lin_index(i)/num_rows) + 1;
        edge_y = edges_lin_index(i) - num_rows*(edge_x-1);
        if restart == 1 || (restart == 0 && (edge_y-y0) + (edge_x-x0) <= th)
            for j=max(edge_x - r_max,1):min(edge_x + r_max,num_cols)
                for k=max(edge_y - r_max,1):min(edge_y + r_max,num_rows)
                    radius = max(ceil(sqrt((edge_x - j)^2 + (edge_y - k)^2)),1);
                    votes(j,k,radius) = votes(j,k,radius) + 1;
                    votes(j,k,radius+1) = votes(j,k,radius+1) + 1;
                    if radius>1
                        votes(j,k,radius-1) = votes(j,k,radius-1) + 1;
                    end
                end
            end
        end
    end
    [c,i] = max(votes(:));
    r = floor(i/(num_cols*num_rows)) + 1;
    y0 = floor((i - num_cols*num_rows*(r-1))/num_cols) + 1;
    x0 = (i - num_cols*num_rows*(r-1)) - num_cols*(y0-1);
    z0 = R*focus/r;
    
    if c > 0.6*c_mean && r >= 0.75*mean && ((r <= 2*mean && mean>0) || mean==0)
        counts = cat(2,counts,r);
        c_counts = cat(2,c_counts,c);
        first_time_flag = 1;
        frames_with_ball = frames_with_ball + 1;
        if restart == 1
            restart = 0;
            start_frame = frames_with_ball;
        end
        
        
        S_G = Rot'*([(x0-num_cols/2)*z0/focus;(y0-num_rows)*z0/focus;z0] - Translation);
        
        %measurement update
        Y = S_G - (H*State);
        S = H*P_uncertainity*H' + R_noise;
        K = P_uncertainity*H'/S;
        State = State + (K*Y);
        P_uncertainity = (eye(9) - K*H)*P_uncertainity;
        
        %prediction
        if State(2) + R > 0
            State = F_bounce*State;
        end
        if State(1) - R < 0 || State(1) + R > num_cols
            State = F_side*State;
        end
        State = State_Transition_Matrix*State;
        P_uncertainity = State_Transition_Matrix*P_uncertainity*State_Transition_Matrix' + Q;
        next_state_g = State;
        number_of_predictions = 10;
        for predicted_state=1:number_of_predictions
            if next_state_g(2,size(next_state_g,2)) + R > 0
                next_state_g(:,size(next_state_g,2)) = ...
                    F_bounce*next_state_g(:,size(next_state_g,2));
            end
            if next_state_g(1,size(next_state_g,2)) - R < 0 ||...
                    next_state_g(1,size(next_state_g,2)) + R > num_cols
                next_state_g(:,size(next_state_g,2)) = ...
                    F_side*next_state_g(:,size(next_state_g,2));
            end
            next_state_g = cat(2,next_state_g,State_Transition_Matrix*...
                next_state_g(:,size(next_state_g,2)));
        end
        
        predicted_position = Rot*next_state_g(1:3,:) + ...
            repmat(Translation,1,number_of_predictions + 1);
        
        if frames_with_ball > start_frame
            if frames_with_ball-start_frame >= window
                mean = sum(counts(frames_with_ball-(window-1):end))/window;
                c_mean = sum(c_counts(frames_with_ball-(window-1):end))/window;
            else
                mean = sum(counts(start_frame+1:end))/(size(counts,2)-start_frame);
                c_mean = sum(c_counts(start_frame+1:end))/(size(c_counts,2)-start_frame);
            end
        end
        
        imshow(uint8(255*img),map)
        viscircles([x0,y0],r,'EdgeColor',[0,0,0],'LineWidth',2.5)
        hold on
        x_p = (predicted_position(1,:)*focus./predicted_position(3,:)) + num_cols/2;
        y_p = predicted_position(2,:)*focus./predicted_position(3,:) + num_rows;
        line(cat(2,x0,x_p),cat(2,y0,y_p),'LineWidth',1.5);
        hold on
        viscircles([x_p(number_of_predictions+1),y_p(number_of_predictions+1)],...
            R*focus/predicted_position(3,number_of_predictions+1),...
            'EdgeColor',[1,0,0],'LineWidth',2.5)
        M(frame) = getframe();
    else
        State = State_Transition_Matrix*State;
        if first_time_flag == 1
            first_time_flag = 0;
        end
        
        restart = 1;
        imshow(uint8(255*img),map)
        M(frame) = getframe();
    end
end
movie2avi(M, 'gaze.avi','quality',100,'fps',10,'compression','Cinepak');
% close all

