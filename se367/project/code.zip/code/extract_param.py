import sys, pygame,time, math, numpy, operator
from GIFImage import *
from Canny import *
from PIL import Image, ImageFilter

pygame.init()

ball = GIFImage("video.gif")

size = width, height = 640, 480
R_max = 50
th = 20
max_cen_x, max_cen_y = width + th + 10, height + th + 10
black = 0, 0, 0

##votes = numpy.zeros((width, height, int(math.ceil(R_max*math.sqrt(2) + 3))), dtype=int)

screen = pygame.display.set_mode(size)
while ball.cur < ball.breakpoint-1:

    ball.render(screen, (0,0))

    ## Uses kernel (FAST but POOR)
##    string = pygame.image.tostring(ball.frames[ball.cur][0], 'RGB')
##    im = Image.fromstring('RGB', (640,480), string)
##    im=im.convert("L")
##    #((3, 3), 1, 0, (-1, -1, -1, -1, 8, -1, -1, -1, -1))
##    im = im.filter(ImageFilter.Kernel((3,3), (-1, -1, -1, -1, 7, -1, -1, -1, -1), scale=1, offset=0))
####    im.show()
##    array = numpy.asarray(im)

    ## Uses Canny (SLOW but GREAT)
    array = pygame.surfarray.array2d(ball.frames[0][0])
    th = 50
    canny = Canny(array,math.sqrt(2),th,0.4*th)
    im = canny.grad
    im = Image.fromarray(im)
    im.show()
    array = numpy.asarray(im)

    R_bound = int(math.ceil(R_max*math.sqrt(2) + 3))
    votes = numpy.zeros((width, height, R_bound), dtype=int)

    indices = numpy.where(array == 255)
    for index in range(len(indices[0])):
        #edge_y = int(index/width)
        #edge_x = index - width*edge_y
        edge_y = indices[0][index]
        edge_x = indices[1][index]
##        print index, edge_x, edge_y
        if index > 0 and (edge_y-max_cen_y) + (edge_x-max_cen_x) > th:
            pass
        else:
            for cen_x in range(max(edge_x - R_max,1), min(edge_x + R_max,width)):
                for cen_y in range(max(edge_y - R_max,1), min(edge_y + R_max,height)):
                    radius = int(math.ceil(math.sqrt((edge_x - cen_x)**2 + (edge_y - cen_y)**2)))
                    votes[cen_x][cen_y][radius] += 1


    max_votes_index = argmax(votes)
    max_cen_x = int(max_votes_index/(height*R_bound))
    max_cen_y = int((max_votes_index - height*R_bound*max_cen_x)/R_bound)
    max_radius = max_votes_index - height*R_bound*max_cen_x - R_bound*max_cen_y
    print max_cen_x, max_cen_y, max_radius

    screen.fill(black)
    pygame.draw.circle(ball.frames[ball.cur][0], (0,0,255), (max_cen_x, max_cen_y), max_radius, 3)
    screen.blit(ball.frames[ball.cur][0], (0,0))
    pygame.display.flip()
    






    
    


