close all; clear all; clc;

number = 1;
f = fopen(cat(2,'Parameters/parameters',num2str(number),'.txt'),'r');
f2 = fopen(cat(2,'New Parameters/parameters',num2str(number),'.txt'),'w');

while ~feof(f)
    line_count = 0;
    characters = 0;
    line = fgetl(f);
    while ~isempty(line)
        line_count = line_count + 1;
        characters = characters + length(line);
        line = fgetl(f);
    end
    
    if line_count > 5
        fseek(f,-(characters+line_count+1),'cof');
        line = fgetl(f);
        while ~isempty(line)
            fprintf(f2,'%s\n',line);
            line = fgetl(f);
        end
        fprintf(f2,'\n');
    end
    
end
fclose(f);
fclose(f2);