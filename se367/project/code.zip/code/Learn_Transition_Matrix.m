clear all; close all; clc;

dt = 0.033;
X = [];
y1 = [];y2 = [];y3 = [];y4 = [];y5 = [];y6 = [];y7 = [];y8 = [];y9 = [];
for number = 1:1
    f = fopen(cat(2,'New Parameters/parameters',num2str(number),'.txt'),'r');

    P = fscanf(f,'%f %f %f');
    P = reshape(P,[3 size(P,1)/3])';
    fclose(f);

    V = zeros(1,3);
    for i=2:size(P,1)
        V = cat(1,V,(P(i,:)-P(i-1,:))/dt);
    end

    A = zeros(1,3);
    for i=2:size(P,1)
        A = cat(1,A,(V(i,:)-V(i-1,:))/dt);
    end

    f2 = fopen(cat(2,'Database/parameters/ROT',num2str(number),'.txt'),'r');

    R = fscanf(f2,'%f %f %f');
    R = reshape(R,[3 size(R,1)/3])';
    fclose(f2);

    R_9_9 = cat(1,cat(2,R,zeros(3,3),zeros(3,3)),...
            cat(2,zeros(3,3),R,zeros(3,3)),cat(2,zeros(3,3),zeros(3,3),R));

    % R_9_9*R_9_9'

    S_G = R_9_9'*cat(1,P',V',A');

    for i=1:size(P,1)
        if i==1
            X = cat(1,X,S_G(:,i)');
        elseif i==size(P,1)
            y1 = cat(1,y1,S_G(1,i));
            y2 = cat(1,y2,S_G(2,i));
            y3 = cat(1,y3,S_G(3,i));
            y4 = cat(1,y4,S_G(4,i));
            y5 = cat(1,y5,S_G(5,i));
            y6 = cat(1,y6,S_G(6,i));
            y7 = cat(1,y7,S_G(7,i));
            y8 = cat(1,y8,S_G(8,i));
            y9 = cat(1,y9,S_G(9,i));
        else
            X = cat(1,X,S_G(:,i)');
            y1 = cat(1,y1,S_G(1,i));
            y2 = cat(1,y2,S_G(2,i));
            y3 = cat(1,y3,S_G(3,i));
            y4 = cat(1,y4,S_G(4,i));
            y5 = cat(1,y5,S_G(5,i));
            y6 = cat(1,y6,S_G(6,i));
            y7 = cat(1,y7,S_G(7,i));
            y8 = cat(1,y8,S_G(8,i));
            y9 = cat(1,y9,S_G(9,i));
        end
    end
end

Ideal_Transition_Matrix = [1,0,0,dt,0,0,(dt^2)/2,0,0;
                           0,1,0,0,dt,0,0,(dt^2)/2,0;
                           0,0,1,0,0,dt,0,0,(dt^2)/2;
                           0,0,0,1,0,0,dt,0,0;
                           0,0,0,0,1,0,0,dt,0;
                           0,0,0,0,0,1,0,0,dt;
                           0,0,0,0,0,0,1,0,0;
                           0,0,0,0,0,0,0,1,0;
                           0,0,0,0,0,0,0,0,1];

Learnt_Transition_Matrix = cat(2,pinv(X)*y1,pinv(X)*y2,pinv(X)*y3,pinv(X)*y4,...
                           pinv(X)*y5,pinv(X)*y6,pinv(X)*y7,pinv(X)*y8,pinv(X)*y9)';

Error = Ideal_Transition_Matrix - Learnt_Transition_Matrix
