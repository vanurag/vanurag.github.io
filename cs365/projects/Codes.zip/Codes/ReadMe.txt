Make sure you have fllowing directories in the current workspace:
'DATA': Store the videos in the format as mentioned in 'STIP.m'
'STIP': This directory stores 3-D matrices indicating STIP points for each video
'Videos': This directory stores frames of each video in greyscale format.
'HOG': This directory stores HoG descriptors of each video.
'Feature_Histograms': This directory stores Featuer histograms of each video both as an array and as a picture in '.jpeg' format.

Unzip the 'Codes.zip' into workspace and run the codes in following order:
1. 'STIP.m' to get STIPs of each video
2. 'saving_video.m' to save frames of each video
3. 'Collecting_HOG.m' to get HoG descriptors of each video
4. Concatanate the HoG descriptors of all the videos into one single matrix according to the format specified in 'vgg_kmeans.m' and save it in workspace by name 'hogdescriptors.mat'
5. 'vgg_kmeans.m' on 'hogdescriptors.mat' to get cluster centroids. Save the centroids matrix in the workspace.
6. 'feature_histogram.m' to compute feature histograms of each video
7. These histograms go into SVM for training phase