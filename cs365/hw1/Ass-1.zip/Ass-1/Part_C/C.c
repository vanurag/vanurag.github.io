#include "Functions.h"

main()
{
    char dof[4]="XXXX"; //degrees of freedom, X => can't move in that direction.
    char max[5]="XXXX"; //stores sides with maximum dirt in the neighbourhood of present state
    float performance = 0.0;
    int i,j,moves_made=0,N = 5;     //change N to print the grid every N steps
    //FILE *fp;

    //fp = fopen("vanurag_hw1COut.txt","w");      // to write the results
    //srand((unsigned)time(NULL));
    Get_Data();
    float *grid=malloc(sizeof(float)*rows*cols);   // creating space for grid storage.
    float *memory=malloc(sizeof(float)*rows*cols); // memory
    Load_Grid(grid,memory);           // grid is loaded and memory initialized
    Update_Memory(memory,grid);
    printf("Starting point: (%d,%d)\n",curr_x,curr_y);

    int haha=0;

    while (moves_made<moves){

        if (moves_made%N == 0){
            printf("\n ");
            for (i=0;i<rows;i++){
                for (j=0;j<cols;j++){
                    if ((i == curr_x-1)&&(j == curr_y-1))
                        printf("[%.1f] ",*(grid+cols*i+j));
                    else
                        printf(" %.1f  ",*(grid+cols*i+j));
                }
                printf("\n ");
            }
            printf("\n");
        }

        DOF(dof);
        //printf("\n%d\n",strcspn(dof,"X"));
        char move;
        max[0] = dof[0];
        for (i=1;i<strcspn(dof,"X");i++){
            if (Dirt(dof[i],grid) > Dirt(max[0],grid))
                max[0] = dof[i];                   // max[0] has one of the sides with max dirt
        }


        for (i=0,j=0;i<strcspn(dof,"X");i++){
            if ((Dirt(dof[i],grid) == Dirt(max[0],grid)) && (dof[i]!=max[0])){//other sides with max dirt as well
                j++;
                max[j] = dof[i];
                //printf("\n%s\n",max);
            }
        }
        //printf("\n%d\n",strcspn(max,"X"));
        //printf("\n%f\n",Dirt(max[0],grid));
        if (Dirt(max[0],grid)==0.0){
            move = Nearest(memory); //chosing shortest path to non zero value square if surrounded by all 0
            //printf("\nyeah %c\n",move);
        }
        else{
            //move = max[rand()%(strcspn(max,"X"))];  // choosing randomly anomg sides with max dirt
            move = Unexplored(memory,max);
            //printf("%s",max);
            //printf("\nburr\n");
        }

        for (i=0;i<4;i++){
            dof[i] = 'X';
            max[i] = 'X';
        }

        if (Dirt('C',grid) != 0.0){

//            if (((performance+Dirt(move,grid))/(moves_made+2) )>((performance+Dirt('C',grid))/(moves_made+1))){
//                if (haha%2 == 0){
//                    goto jump;      // this is done to maximize performance/moves ratio
//                    haha++;
//                }
//            }

//            if (Dirt('C',grid) < 0.5){
//                    goto jump;      // this is done to maximize performance/moves ratio
//            }


            performance = performance + Dirt('C',grid);
            printf("%c %.1f\n",'S',performance);
            Update_Grid_Status(grid);
            Update_Memory(memory,grid);
            moves_made++;

        }


        else{

//            jump:

            Update_Memory(memory,grid);
            printf("%c %.1f\n",move,performance);
            Update_Location(move);
            Update_Memory(memory,grid);
            if (move != 'N')
                moves_made++;

        }

//        if (moves_made%N == 0){
//            printf("\n ");
//            for (i=0;i<rows;i++){
//                for (j=0;j<cols;j++){
//                    if ((i == curr_x-1)&&(j == curr_y-1))
//                        printf("[%.1f] ",*(grid+cols*i+j));
//                    else
//                        printf(" %.1f  ",*(grid+cols*i+j));
//                }
//                printf("\n ");
//            }
//            printf("\n");
//        }


//        float bla = 0.0;
//        for (i=0;i<rows;i++){
//            for (j=0;j<cols;j++){
//                bla = bla + *(memory+cols*i+j);
//            }
//        }
//        printf("\nbla - %f\n",bla);

        if (move == 'N'){
            break;
        }
//        bla = 0.0;

    }
//    int num1=1,num2=-3,num3=2;
//    int ma;
//    ma = (int)fmax(num1,fmax(num2,num3));
//    if (ma == num3)
//        printf("%d",ma);
    printf("\nNumber of moves - %d\n",moves_made);
    printf("Performance - %.1f\n",performance);
    //fclose(fp);
//    printf("%.1f\n",performance);
//    printf("No. of moves taken: %d\n",moves_made);

}

