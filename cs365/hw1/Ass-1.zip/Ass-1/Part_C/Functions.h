#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int curr_x,curr_y,rows,cols,moves,init_x,init_y;          // global variable
//float *grid;
void DOF(char *dof)    // function which tells the degrees of freedom
{
    int next = 0;
    if (curr_y != 1){
        dof[next] = 'L';
        next++;
    }
    if (curr_y != cols){
        dof[next] = 'R';
        next++;
    }
    if (curr_x != 1){
        dof[next] = 'U';
        next++;
    }
    if (curr_x != rows)
        dof[next] = 'D';
}

void Update_Location(char move)     // updates current location after taking a particular move
{
    if (move == 'L')
        curr_y=curr_y-1;
    if (move == 'R')
        curr_y=curr_y+1;
    if (move == 'U')
        curr_x=curr_x-1;
    if (move == 'D')
        curr_x=curr_x+1;
}

void Get_Data()    // reads data from the text file at the start of the program
{
    //FILE *fp;
    int i;

    //fp = fopen("environ.txt","r");
    //fseek(fp, 5, SEEK_SET);
    scanf("GRID: %d %d",&rows,&cols);

    char buff[10+(5*cols)];

    for (i=0;i<2+rows;i++){
        gets(buff,10+(5*cols),stdin);
    }

    //fseek(fp, 10, SEEK_CUR);
    scanf("    MOVES: %d",&moves);

    gets(buff,10+(5*cols),stdin);

    //fseek(fp, 12, SEEK_CUR);
    scanf("    INITIAL: %d %d",&init_x,&init_y);
    curr_x = init_x;
    curr_y = init_y;
    //fclose(fp);
}

void Load_Grid(float *grid,float* memory)      // loads grid from text file at the start of the program
{                               // and initializes memory as completely unknown territory(marked with '1.1')
    //FILE *fp;
    int i,j;
    char buff[10+(5*cols)];

    //fp = fopen("environ.txt","r");
    gets(buff,10+(5*cols),stdin);
    gets(buff,10+(5*cols),stdin);

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            scanf("%f",grid+cols*i+j);
        }
        gets(buff,10+(5*cols),stdin);
    }

//    for (i=0;i<rows;i++){
//        for (j=0;j<cols;j++){
//            printf("%f ",*(grid+cols*i+j));
//        }
//        printf("\n");
//    }
//    printf("\n");

    //fclose(fp);

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            *(memory+cols*i+j) = 1.1;           // initializing memory
        }
    }

}

float Dirt(char side,float *grid)   // returns value of dirt at the current location and the 4 sides
{
    switch (side){
    case 'C':
       return *(grid+cols*(curr_x-1)+(curr_y-1));   // current location dirt value
       break;
    case 'L':
       return *(grid+cols*(curr_x-1)+(curr_y-2));
       break;
    case 'R':
       return *(grid+cols*(curr_x-1)+(curr_y));
       break;
    case 'U':
       return *(grid+cols*(curr_x-2)+(curr_y-1));
       break;
    case 'D':
       return *(grid+cols*(curr_x)+(curr_y-1));
       break;
    }

}

void Update_Grid_Status(float *grid)  // updates grid after sucking
{
    int i,j;

    *(grid+cols*(curr_x-1)+(curr_y-1)) = 0.0;

//    for (i=0;i<rows;i++){
//        for (j=0;j<cols;j++){
//            printf("%f ",*(grid+cols*i+j));
//        }
//        printf("\n");
//    }
//    printf("\n");
}

void Update_Memory(float *memory,float *grid)   // updates memory(curr location+sides dirt values)
{
    int i,j;

    *(memory+cols*(curr_x-1)+(curr_y-1)) = *(grid+cols*(curr_x-1)+(curr_y-1));

    if (curr_y>1)
        *(memory+cols*(curr_x-1)+(curr_y-2)) = *(grid+cols*(curr_x-1)+(curr_y-2));
    if (curr_y<cols)
        *(memory+cols*(curr_x-1)+(curr_y)) = *(grid+cols*(curr_x-1)+(curr_y));
    if (curr_x>1)
        *(memory+cols*(curr_x-2)+(curr_y-1)) = *(grid+cols*(curr_x-2)+(curr_y-1));
    if (curr_x<rows)
        *(memory+cols*(curr_x)+(curr_y-1)) = *(grid+cols*(curr_x)+(curr_y-1));


//    printf("\n ");
//    for (i=0;i<rows;i++){
//        for (j=0;j<cols;j++){
//            if (*(memory+cols*i+j) <= 1.1){
//                if ((i == curr_x-1)&&(j == curr_y-1))
//                    printf("[%.1f] ",*(grid+cols*i+j));
//                else
//                    printf(" %.1f  ",*(grid+cols*i+j));
//            }
//            else
//                printf("  X   ");
//        }
//        printf("\n ");
//    }
//    printf("\n");

}

char Nearest(float *memory)         // gives direction for nearest non zero square if surrounded by all 0
{                                  // Order of preference: L>U>R>D


    int exp(char move,int i,int j)
    {
        if (move=='L')
            return j-(curr_y-1);
        else if (move=='U')
            return i-(curr_x-1);
        else if (move=='R')
            return (curr_y-1)-j;
        else
            return (curr_x-1)-i;
    }

    int i=0,j=0,min;
    char next='X';

    char preference[4]={'X','X','X','X'};

    if (init_x <= rows/2){
        if (init_y <= cols/2){
            preference[0]='D';
            preference[1]='R';
            preference[2]='U';
            preference[3]='L';
            //preference[0]='R';
//            preference[1]='D';
//            preference[2]='L';
//            preference[3]='U';
        }
        else{
            preference[0]='L';
            preference[1]='D';
            preference[2]='R';
            preference[3]='U';
            //preference[0]='D';
//            preference[1]='L';
//            preference[2]='U';
//            preference[3]='R';
        }
    }
    else {
        if (init_y <= cols/2){
//            preference[0]='U';
//            preference[1]='R';
//            preference[2]='D';
//            preference[3]='L';
            preference[0]='R';
            preference[1]='U';
            preference[2]='L';
            preference[3]='D';
        }
        else{
//            preference[0]='L';
//            preference[1]='U';
//            preference[2]='R';
//            preference[3]='D';
            preference[0]='U';
            preference[1]='L';
            preference[2]='D';
            preference[3]='R';
        }
    }


//    printf("\n%d %d\n",init_x,init_y);
//    char preference[4]={'D','L','U','R'};
//    char preference[4]={'D','R','U','L'};
//    char preference[4]={'U','R','D','L'};
//    char preference[4]={'U','L','D','R'};
//    char preference[4]={'L','U','R','D'};
//    char preference[4]={'L','D','R','U'};
//    char preference[4]={'R','U','L','D'};
//    char preference[4]={'R','D','L','U'};

//    #define exp_L j-(curr_y-1)
//    #define exp_U i-(curr_x-1)
//    #define exp_R (curr_y-1)-j
//    #define exp_D (curr_x-1)-i
//    int exp[4]={exp_L,exp_U,exp_R,exp_D};
    //int exp[4]={exp_U,exp_L,exp_D,exp_R};
    float max = 0.0;

    min = rows+cols;
    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            if ((abs(i+1-curr_x)+abs(j+1-curr_y) < min) && (*(memory+cols*i+j) != 0.0) && ((i!=curr_x-1) || (j!=curr_y-1))){
                min = abs(i+1-curr_x)+abs(j+1-curr_y);      // finding min distance to non zero entry
                //printf("\nmin %d %d %d;%d %d\n",min,i,j,curr_x,curr_y);
            }
        }
        //printf("\nyes\n");
    }


        for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            if ((abs(i+1-curr_x)+abs(j+1-curr_y) == min) && exp(preference[0],i,j)<0 && (*(memory+cols*i+j) != 0.0)){
                next = preference[0];
                goto jump1;
            }
        }
    }
    jump1:
    if (next!='X')
        return next;

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            if ((abs(i+1-curr_x)+abs(j+1-curr_y) == min) && exp(preference[1],i,j)<0 && (*(memory+cols*i+j) != 0.0)){
                //printf("\nyes\n");
                next = preference[1];
                goto jump2;
            }
        }
    }
    jump2:
    if (next!='X')
        return next;

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            if ((abs(i+1-curr_x)+abs(j+1-curr_y) == min) && exp(preference[2],i,j)<0 && (*(memory+cols*i+j) != 0.0)){
                next = preference[2];
                goto jump3;
            }
        }
    }
    jump3:
    if (next!='X')
        return next;

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            if (abs(i+1-curr_x)+abs(j+1-curr_y) && exp(preference[3],i,j)<0 && (*(memory+cols*i+j) != 0.0)){
                next = preference[3];
                goto jump4;
            }
        }
    }
    jump4:
    if (next!='X')
        return next;

    return 'N';

}



char Unexplored(float *memory,char* max)    // gives nearest distance to non zero square. takes move as input.
{

    int count(char side)
    {
        int i,j,count_L=0,count_U=0,count_R=0,count_D=0;

        for (i=0;i<rows;i++){
            for (j=0;j<cols;j++){
                if ( (*(memory+cols*i+j)>1.0) && j-(curr_y-1) < 0 )
                    count_L++;
                if ( (*(memory+cols*i+j)>1.0) && j-(curr_y-1) > 0 )
                    count_R++;
                if ( (*(memory+cols*i+j)>1.0) && i-(curr_x-1) < 0 )
                    count_U++;
                if ( (*(memory+cols*i+j)>1.0) && i-(curr_x-1) > 0 )
                    count_D++;
            }
        }

        if (side == 'L')
            return count_L;
        else if (side == 'U')
            return count_U;
        else if (side == 'R')
            return count_R;
        else
            return count_D;

    }

    int i,max_count=0;

    for (i=0;i < strcspn(max,"X");i++){
        max_count = (int)fmax(count(max[i]),max_count);
    }

    for (i=0;i < strcspn(max,"X");i++){
        if (max_count == count(max[i]))
            return max[i];
    }

}



















