1. All the functions are in seperate folder "Functions.h"
2. Executable files are already present in the corresponding folders.
2. Compile Part - A by typing
./A < environ.txt > vanurag_hw1AOut.txt
Part - B by typing
./B < environ.txt > vanurag_hw1AOut.txt
Part - C by typing
./C < environ.txt > vanurag_hw1AOut.txt
in the terminal.