#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include <time.h>
#include <string.h>

int curr_x,curr_y,rows,cols,moves;          // global variable
//float *grid;
void DOF(char *dof)    // function which tells the degrees of freedom
{
    int next = 0;
    if (curr_y != 1){
        dof[next] = 'L';
        next++;
    }
    if (curr_y != cols){
        dof[next] = 'R';
        next++;
    }
    if (curr_x != 1){
        dof[next] = 'U';
        next++;
    }
    if (curr_x != rows)
        dof[next] = 'D';
}

void Update_Location(char move)     // updates current location after taking a particular move
{
    if (move == 'L')
        curr_y=curr_y-1;
    if (move == 'R')
        curr_y=curr_y+1;
    if (move == 'U')
        curr_x=curr_x-1;
    if (move == 'D')
        curr_x=curr_x+1;
}

void Get_Data()    // reads data from the text file at the start of the program
{
    //FILE *fp;
    int i;

    //fp = fopen("environ.txt","r");
    //fseek(fp, 5, SEEK_SET);
    scanf("GRID: %d %d",&rows,&cols);

    char buff[10+(5*cols)];

    for (i=0;i<2+rows;i++){
        gets(buff,10+(5*cols),stdin);
    }

    //fseek(fp, 10, SEEK_CUR);
    scanf("    MOVES: %d",&moves);

    gets(buff,10+(5*cols),stdin);

    //fseek(fp, 12, SEEK_CUR);
    scanf("    INITIAL: %d %d",&init_x,&init_y);
    curr_x = init_x;
    curr_y = init_y;
    //fclose(fp);
}

void Load_Grid(float *grid,float* memory)      // loads grid from text file at the start of the program
{                               // and initializes memory as completely unknown territory(marked with '1.1')
    //FILE *fp;
    int i,j;
    char buff[10+(5*cols)];

    //fp = fopen("environ.txt","r");
    gets(buff,10+(5*cols),stdin);
    gets(buff,10+(5*cols),stdin);

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            scanf("%f",grid+cols*i+j);
        }
        gets(buff,10+(5*cols),stdin);
    }

//    for (i=0;i<rows;i++){
//        for (j=0;j<cols;j++){
//            printf("%f ",*(grid+cols*i+j));
//        }
//        printf("\n");
//    }
//    printf("\n");

    //fclose(fp);

    for (i=0;i<rows;i++){
        for (j=0;j<cols;j++){
            *(memory+cols*i+j) = 1.1;           // initializing memory
        }
    }

}

float Dirt(float *grid)   // returns value of dirt at the current location in grid
{
    return *(grid+cols*(curr_x-1)+(curr_y-1));
}

void Update_Grid_Status(float *grid)  // updates grid after sucking
{
    int i,j;

    *(grid+cols*(curr_x-1)+(curr_y-1)) = 0.0;

//    for (i=0;i<rows;i++){
//        for (j=0;j<cols;j++){
//            printf("%f ",*(grid+cols*i+j));
//        }
//        printf("\n");
//    }
//    printf("\n");
}





















