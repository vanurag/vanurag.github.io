#include "Functions.h"

main()
{
    char dof[4]="XXXX"; //degrees of freedom, X => can't move in that direction.
    char max[5]="XXXX"; //stores sides with maximum dirt in the neighbourhood of present state
    float performance = 0.0;
    int i,j,moves_made=0,N = 5;
    //FILE *fp;

    //fp = fopen("vanurag_hw1BOut.txt","w");      // to write the results
    srand((unsigned)time(NULL));
    Get_Data();
    float *grid=malloc(sizeof(float)*rows*cols);   // creating space for grid storage.
    Load_Grid(grid);           // grid is loaded
    printf("Starting point: (%d,%d)\n",curr_x,curr_y);

    while (moves_made<moves){

        if (moves_made%N == 0){
            printf("\n ");
            for (i=0;i<rows;i++){
                for (j=0;j<cols;j++){
                    if ((i == curr_x-1)&&(j == curr_y-1))
                        printf("[%.1f] ",*(grid+cols*i+j));
                    else
                        printf(" %.1f  ",*(grid+cols*i+j));
                }
                printf("\n ");
            }
            printf("\n");
        }

        if (Dirt('C',grid) != 0.0){
            performance = performance + Dirt('C',grid);
            printf("%c %.1f\n",'S',performance);
            Update_Grid_Status(grid);
            moves_made++;
        }
        else{

            DOF(dof);
            //printf("\n%d\n",strcspn(dof,"X"));
            char move;
            max[0] = dof[0];
            for (i=1;i<strcspn(dof,"X");i++){
                if (Dirt(dof[i],grid) > Dirt(max[0],grid))
                    max[0] = dof[i];                   // max[0] has one of the sides with max dirt
            }


            for (i=0,j=0;i<strcspn(dof,"X");i++){
                if ((Dirt(dof[i],grid) == Dirt(max[0],grid)) && (dof[i]!=max[0])){//other sides with max dirt as well
                    j++;
                    max[j] = dof[i];
                    //printf("\n%s\n",max);
                }
            }
            //printf("\n%d\n",strcspn(max,"X"));
            move = max[rand()%(strcspn(max,"X"))];  // choosing randomly anomg sides with max dirt
            for (i=0;i<4;i++){
                dof[i] = 'X';
                max[i] = 'X';
            }
            printf("%c %.1f\n",move,performance);
            Update_Location(move);
            moves_made++;

        }

    }
    printf(fp,"Number of moves - %d\n",moves_made);
    printf(fp,"Performance - %.1f\n",performance);
    //fclose(fp);
    //printf("%.1f\n",performance);

}
