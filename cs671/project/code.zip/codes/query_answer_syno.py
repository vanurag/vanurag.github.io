#input: query_answer.py <ei> <rij> <ej>		for empty use <_>

import sys
from nltk.stem.lancaster import LancasterStemmer
from nltk.tokenize.punkt import PunktWordTokenizer
from nltk.corpus import wordnet as wn

st = LancasterStemmer()

q1 = sys.argv[1]
q2 = sys.argv[2]
q3 = sys.argv[3]

mypath = 'medicine_trusted_tuples.txt'
file = open(mypath,'r').readlines()

trusted_tuple=[]
for line in file:
	trusted_tuple.append(eval(line))

#for i in trusted_tuple:
#	print i

e_i_search=[]
r_i_j_search=[]
e_j_search=[]

e_i_search_stem=[]
r_i_j_search_stem=[]
e_j_search_stem=[]

q1_stem = st.stem(q1)
q2_stem = st.stem(q2)
q3_stem = st.stem(q3)

print q1_stem,q2_stem,q3_stem

q2_syn=[]

syns = wn.synsets(q2)

for s in syns:
	for l in s.lemmas:
		if l.name not in q2_syn:
			q2_syn.append(l.name)
	arr =  s.hypernyms()
	for hyn in arr:
		for l in hyn.lemmas:
			if l.name not in q2_syn:
				q2_syn.append(l.name) 
	

#print q2_syn

q2_syn_stem = [st.stem(x) for x in q2_syn]

#print q2_syn_stem

for ei,rij,ej in trusted_tuple:
	ei_stem = [st.stem(x) for x in PunktWordTokenizer().tokenize(ei)]
	rij_stem = [st.stem(x) for x in PunktWordTokenizer().tokenize(rij)]
	ej_stem = [st.stem(x) for x in PunktWordTokenizer().tokenize(ej)]

	if q1_stem in ei_stem and q1 != '_':
		e_i_search.append((ei,rij,ej));
		e_i_search_stem.append((ei_stem,rij_stem,ej_stem));

	for lp in q2_syn_stem:
		if lp in rij_stem and q2 != '_':
			r_i_j_search.append((ei,rij,ej));
			r_i_j_search_stem.append((ei_stem,rij_stem,ej_stem));
			break

	if q3_stem in ej_stem and q3 != '_':
		e_j_search.append((ei,rij,ej));
		e_j_search_stem.append((ei_stem,rij_stem,ej_stem));


#print e_i_search,r_i_j_search,e_j_search

query_result = e_i_search + r_i_j_search + e_j_search
query_result_stem = e_i_search_stem + r_i_j_search_stem + e_j_search_stem

set_ei = set(e_i_search)
set_rij = set(r_i_j_search)
set_ej = set(e_j_search)

list3 = set.intersection(set_ej,set_rij,set_ei)
list2 = set([''])
if q1=='_' and q2!='_' and q3!='_':
	list2 = set.intersection(set_ej,set_rij)

if q1!='_' and q2=='_' and q3!='_':
	list2 = set.intersection(set_ei,set_ej)

if q1!='_' and q2!='_' and q3=='_':
	list2 = set.intersection(set_ej,set_ei)

list1 = set.union(set_ei,set_ej,set_rij)
list1 = set.difference(list1,set.union(list2,list3))

print list3
print list2
print list1