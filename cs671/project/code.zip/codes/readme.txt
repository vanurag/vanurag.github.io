1. Install Jython and download stanford parser dependencies from: http://nlp.stanford.edu/downloads/lex-parser.shtml#Download
2. Unpack englishPCFG.ser.gz from stanford parser .jar file
3. Run collect_training_data.py for extracting trusted and untrusted tuples without noun-phrase chunking. change the 'input' variable accordingly. The usage is indicated in the file: "jython collect_training_data.py <path to englishPCFG.ser.gz>"
4. Run collect_training_data_with_chunker.py  to get trusted and untrusted tuples with noun-phrase chunking. Place the input sentences in test_corpus.txt. The trusted tuples will be stored in trusted_tuples.txt, untrusted ones in untrusted_tuples.txt and a shorter version of the same (randomly picked) in untrusted_tuples_short.txt
5. Query module implemented in query_answer_syno.py. If querying for WHAT energizes kinase?, you execute as: "python query_answer_syno.py _ energizes kinase"
