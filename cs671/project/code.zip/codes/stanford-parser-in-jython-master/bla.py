graph = {}
for i in range(4):
	temp = {i:{}}
	graph = dict(graph.items() + temp.items())
