import glob, re

mypath='/media/Bunny/projects/CS671/project/brown/*'

files = glob.glob(mypath)
path_new = '/media/Bunny/projects/CS671/project/brown_corpus.txt'
f_new = open(path_new,'w')
for i in files:
	f = open(i,'r').read()
	new_str = re.sub(r'/[^ \n]*',' ',f)
	new_str2 = re.sub(r'  ',' ',new_str)
	f_new.write(new_str2)
	
	
