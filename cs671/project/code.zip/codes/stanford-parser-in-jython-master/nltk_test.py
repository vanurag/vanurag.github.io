import nltk
from nltk.corpus import brown

nltk.data.path.append('/media/Bunny/projects/CS671/project/nltk_data')
#print brown.sents()

print len(brown.sents())

f = open('brown_corpus.txt','w')

for i in range(len(brown.sents())):
	f.write(' '.join(brown.sents()[i]))
	f.write('\n')
	#print ' '.join(brown.sents()[i])

f.close()

#f = open('brown_corpus.txt','r').readlines()
#
#for line in f:
#	print line
	
