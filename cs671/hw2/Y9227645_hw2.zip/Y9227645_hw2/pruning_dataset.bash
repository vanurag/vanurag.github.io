#!/bin/bash

sed 's/-\|_\|×\|~\|–\|^\|@\|;\|«\|»\|[\|]\|%\|#\|+\|$\|`\|=\|…\|,\|!\|?\|:\|“\|”\|’\|‘\|"\|\*\|(\|)\|[[:digit:]]\|[a-zA-Z]\|\/\|\\\|\t//g' < Tel_Blogs.txt | sed "s/'//g" | sed "s/\. /\./g" | tr "\." '\n' > Blog_Sentences.txt

sed 's/-\|_\|×\|~\|–\|^\|@\|;\|«\|»\|[\|]\|%\|#\|+\|$\|`\|=\|…\|,\|!\|?\|:\|“\|”\|’\|‘\|"\|\*\|(\|)\|[[:digit:]]\|[a-zA-Z]\|\/\|\\\|\t//g' < Tel_Newspapers.txt | sed "s/'//g" | sed "s/\. /\./g" | tr "\." '\n' > News_Sentences.t

cat News_Sentences.txt Blog_Sentences.txt > Tel_Sentences.txt

cat /dev/null > Tel_Sentences_edited.txt
while read line           
do
	num_words=$(echo $line | wc -w)
	if [ "${num_words/-/}" -gt "1" ]
	then
		echo $line >> Tel_Sentences_edited.txt
	fi
done < Tel_Sentences.txt
