#!/usr/bin/python
# -*- coding: utf-8 -*-

from ngrams import *

#unigram,bigram =  corrections('తెల్లవారు జామున మైదానంలోకి వెళ్లి మూత్ర విసర్జన చేస్తూ కేరింతలు కిట్టారు')
#unigram,bigram =  corrections('అని అమ్ము')
#print unigram
#print bigram

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

f = open('spell_testset.txt','r')
f2 = open('output_on_testet.txt','w')
f3 = open('testset_gt.txt','r')
f4 = open('aspell_output_on_testset.txt','r')

for line_num in range(file_len('spell_testset.txt')):
	text = f.readline()[:-1]
	gt = f3.readline()[:-1]
	aspell_out = f4.readline()[:-1]
	unigram,bigram = corrections(text)
	if gt != text:
		f2.write('Ground Truth: '+gt+'\n')
		f2.write('Misspell: '+text+'\n')
		f2.write('My Unigram Correction: '+unigram+'\n')
		f2.write('My Bigram Correction: '+bigram+'\n')
		f2.write('Aspell Correction: '+aspell_out+'\n')
		f2.write('\n')
		print correct

#print corrections('మా అమ్')

f.close()
f2.close()
f3.close()
f4.close()
