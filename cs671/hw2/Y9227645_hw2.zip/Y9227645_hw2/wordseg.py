#!/usr/bin/python
# -*- coding: utf-8 -*-

from ngrams import *
import sys, os
sys.setrecursionlimit(3000)

#result = segment('అకస్మాత్తుగాఅకాడమి')
#for i in range(len(result)):
	#print result[i].decode('utf-8'), '\t',

#print '\n'

f_source = open('tel_wordseg.txt','r')
f_result = open('tel_wordseg_result_unigram.txt','w')
f_result2 = open('tel_wordseg_result_bigram.txt','w')

for line in f_source:
	result_unigram = segment(line)
	result = segment2(line)
	result_bigram =  result[1]
	for i in range(len(result_unigram)):
		f_result.write(result_unigram[i])
		if i < len(result_unigram) - 1:
			f_result.write(' ')
	for i in range(len(result_bigram)):
		f_result2.write(result_bigram[i])
		if i < len(result_bigram) - 1:
			f_result2.write(' ')

f_source.close()
f_result.close()
f_result2.close()

