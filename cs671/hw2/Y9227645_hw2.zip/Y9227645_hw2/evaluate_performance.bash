#!/bin/bash

#echo Hello World


cat /dev/null > foo.txt

H_total=0	#Total Hits
I_total=0	#Total Insertions
D_total=0	#Total Deletions
Perfect_Match=0
Line_Number=0
while read -r -u3 line1; read -r -u4 line2; 
do 
	Line_Number=`expr $Line_Number + 1`
	#echo "$line1  ||||  $line2"
	morphemes_U=`echo $line1`	#morphemes from Undivide++ output
	morphemes_G=`echo $line2`	#morphemes from Groundtruth
	number_of_morphemes_U=`echo $morphemes_U | awk '{print NF}'`
	number_of_morphemes_G=`echo $morphemes_G | awk '{print NF}'`
	#echo $number_of_morphemes
	seperators_U=();	#position of word breaks with reference to start of that word
	seperators_G=();

	dist_from_start=0
	for i in $(eval echo {1..$number_of_morphemes_U})
	do
		#echo $i
		morpheme_U=`echo $morphemes_U | awk -v x=$i '{print $x}'`
		#echo "${#morpheme}" >> foo.txt
		seperators_U=(${seperators_U[@]} `expr $dist_from_start + ${#morpheme_U}`)
		dist_from_start=`expr $dist_from_start + ${#morpheme_U}`
	done
	#echo -e "\n" >> foo.txt
	echo "Sp:" ${seperators_U[@]:0:`expr $number_of_morphemes_U - 1`} >> foo.txt

	dist_from_start=0
	for i in $(eval echo {1..$number_of_morphemes_G})
	do
		#echo $i
		morpheme_G=`echo $morphemes_G | awk -v x=$i '{print $x}'`
		#echo "${#morpheme}" >> foo.txt
		seperators_G=(${seperators_G[@]} `expr $dist_from_start + ${#morpheme_G}`)
		dist_from_start=`expr $dist_from_start + ${#morpheme_G}`
	done
	#echo -e "\n" >> foo.txt
	echo "Sc:" ${seperators_G[@]:0:`expr $number_of_morphemes_G - 1`} >> foo.txt

	H=0	#Word Hits
	I=0	#Word Insertions
	D=0	#Word Deletions
	I=`expr $number_of_morphemes_G - 1`
	Np_Nc=`expr $number_of_morphemes_U - $number_of_morphemes_G`
	for (( i=0; i<`expr $number_of_morphemes_U - 1`; i++ ))
	do
		number_of_morphemes_G=${#seperators_G[@]}
		#echo ${seperators_U[$i]}
		for (( j=0; j<`expr $number_of_morphemes_G - 1`; j++ ))
		do
			#echo ${seperators_G[$j]}
			temp=`expr ${seperators_U[$i]} - ${seperators_G[$j]}`
			#echo $temp
			if [ "${temp/-/}" -lt "3" ]
			then
				#echo ${seperators_U[$i]} ${seperators_G[$j]}
				H=`expr $H + 1`
				I=`expr $I - 1`
				seperators_G=(${seperators_G[@]:0:$j} ${seperators_G[@]:$(($j + 1))})
				break
			fi
		done
	done
	D=`expr $I + $Np_Nc`

	changes=`expr $I + $D`	#changes to be made for Sp to match Sc
	if [ "$changes" -eq "0" ]
	then
		Perfect_Match=`expr $Perfect_Match + 1`
	fi
	H_total=`expr $H_total + $H`
	I_total=`expr $I_total + $I`
	D_total=`expr $D_total + $D`
	echo "H:"$H "I:"$I "D:"$D "Perfect_Match:"$Perfect_Match>> foo.txt
	Precision=$(echo "scale=3;100.0*$H_total / ($H_total + $I_total)"| bc)
	Recall=$(echo "scale=3;100.0*$H_total / ($H_total + $D_total)"| bc)
	F_Score=$(echo "scale=3;200.0*$H_total / (2.0*$H_total + $I_total + $D_total)"| bc)
	Accuracy=$(echo "scale=3;100.0*$Perfect_Match / $Line_Number"| bc)
	echo "Accuracy:"$Accuracy "Precision:"$Precision "Recall:"$Recall "F-Score:"$F_Score >> foo.txt
	echo -e "\n" >> foo.txt

done 3< tel_wordseg_result_unigram.txt 4< tel_wordseg_gt.txt




