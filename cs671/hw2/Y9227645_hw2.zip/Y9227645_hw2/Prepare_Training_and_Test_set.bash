#!/bin/bash

sort -R Tel_Sentences_edited.txt | head -n 300 > tel_wordseg_gt.txt

sed 's/ //g' tel_wordseg_gt.txt > tel_wordseg.txt

grep -v -f tel_wordseg_gt.txt Tel_Sentences_edited.txt > Tel_Training_Set.txt
