#!/bin/bash

tr ' ' '\n' < Tel_Training_Set.txt | sort | uniq -c | sed -e 's/^[ \t]*//' | grep "["$'\xE0\xB0\x81'"-"$'\xE0\xB0\x83'"]\|["$'\xE0\xB0\x85'"-"$'\xE0\xB0\xBF'"]\|["$'\xE0\xB1\x80'"-"$'\xE0\xB1\x8D'"]\|["$'\xE0\xB1\x95'"-"$'\xE0\xB1\x96'"]\|["$'\xE0\xB1\x98'"-"$'\xE0\xB1\x99'"]\|["$'\xE0\xB1\xA0'"-"$'\xE0\xB1\xA3'"]" > wordcount.txt

awk '{tmp=$1;$1=$2;$2=tmp;print $1 " " $2}' < wordcount.txt > wordcount_edited.txt
