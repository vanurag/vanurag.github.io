#!/usr/bin/python
# -*- coding: utf-8 -*-

from ngrams import *

input_file = 'spellin_errors.txt'
output_file = 'tel_count_1edit.txt'


f = open(input_file,'r')
f2 = open(output_file,'w')
count_dict = {}

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

line_number = 0

for line in f:
	print 'Yet to go:', file_len(input_file)-line_number
	line_number += 1
	[right,wrong] = line.split(' ')
	#count_dict.update(update_edit_count(wrong[:-1], right, 2))
	for key in update_edit_count(wrong[:-1], right, 2):
		if key in count_dict: count_dict[key] += 1
		else: count_dict[key] = 2

#print count_dict
for key in count_dict:
	f2.write(key+'\t'+str(count_dict[key])+'\n')
	#print 'word:', key, ' : ', count_dict[key]

f.close()
f2.close()



