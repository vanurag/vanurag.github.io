#!/bin/bash

sed 's/-\|_\|×\|~\|–\|^\|@\|;\|«\|»\|[\|]\|%\|#\|+\|$\|`\|=\|…\|,\|\.\|!\|?\|:\|“\|”\|’\|‘\|"\|\*\|(\|)\|[[:digit:]]\|[a-zA-Z]\|\/\|\\\|\t//g' < Tel_Blogs.txt | sed "s/'//g" | tr ' ' '\n' > clean_words_Tel_Blogs.txt

sed 's/-\|_\|×\|~\|–\|^\|@\|;\|«\|»\|[\|]\|%\|#\|+\|$\|`\|=\|…\|,\|\.\|!\|?\|:\|“\|”\|’\|‘\|"\|\*\|(\|)\|[[:digit:]]\|[a-zA-Z]\|\/\|\\\|\t//g' < Tel_Newspapers.txt | sed "s/'//g" | tr ' ' '\n' > clean_words_Tel_Newspapers.txt

cat clean_words_Tel_Newspapers.txt clean_words_Tel_Blogs.txt >> clean_words_Tel.txt

sort clean_words_Tel.txt | uniq -c | sed -e 's/^[ \t]*//' > word_frequencies_Tel.txt

## Now open word_frequency_Tel.txt and remove all the foreign words (they are grouped together)
