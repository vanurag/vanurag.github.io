Run following commands in the terminal:

# cd to "telugu_corpus_2012_03_30" directory

bash ./pruning_dataset.bash

# Place the "word_frequencies_Tel_edited.txt" in "FinalDistribution" directory provided on their website
# Run Undivide++

bash ./prepare_test_set.bash
bash ./evaluate_performance.bash

The performance details are stored in "foo.txt"
