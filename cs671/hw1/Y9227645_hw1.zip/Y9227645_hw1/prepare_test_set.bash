#!/bin/bash

## After removing all the foreign language words from word_frequencies_Tel.txt, store the new set of words in word_frequencies_Tel_edited.txt

sort -n word_frequencies_Tel_edited.txt > ordered_word_frequencies_Tel.txt

egrep '^[4-9]|^[1-9][0-9]' ordered_word_frequencies_Tel.txt | grep -P '[^[:ascii:]]{40,}' | sort -R | head -n 300 > test_set_Tel.txt

## Now start annotating (similar to the Undivide++ output) the test set to get a groundtruth

