%function englishHnd_CNN
clear all
clc

cd('D:\study\cs771\Project\codefinal');
addpath(genpath('./DeepLearnToolbox-master'));
%addr = '../../'

%sampleI = imread('dataset/Sample001/img001-001.png');
%imageRows = size(sampleI,1); imageCols = size(sampleI,2);
totalClasses = 62;

thin = '_normalNew';         %'thin' for thin data ; '_normal' for normal data

load(['dataMatrix' thin '/trainDataLabels.mat']);        %2480 x 1
load(['dataMatrix' thin '/trainDataMatrix.mat']);        %2480 x 2304
load(['dataMatrix' thin '/testDataLabels.mat']);         %930 x 1
load(['dataMatrix' thin '/testDataMatrix.mat']);         %930 x 2304
%imshow(reshape(dataMatrix(40,:),48,48));

%transform labels to bitvector
trainLabel = zeros(size(trainDataLabels,1),totalClasses);
for i=1:size(trainDataLabels,1)
    trainLabel(i,trainDataLabels(i))=1;
end
testLabel = zeros(size(testDataLabels,1),totalClasses);
for i=1:size(testDataLabels,1)
    testLabel(i,testDataLabels(i))=1;
end
clear testDataLabels;
clear trainDataLabels;

%RESHAPE(X,M,N..) returns the M-by-N-by-.. matrix whose elements are taken column-wise from X.  An error results if X does not have M*N elements.
trainDataMatrix = double(reshape(trainDataMatrix',48,48,2728));         %2480 Old,  2728 new
trainDataLabels = double(trainLabel');
testDataMatrix = double(reshape(testDataMatrix',48,48,682));            %930 Old, 682 new
testDataLabels = double(testLabel');

%transform dataMatrix
trainDataMatrix = 1-trainDataMatrix;
trainDataMatrix = 254*trainDataMatrix;
trainDataMatrix = 1+trainDataMatrix;
trainDataMatrix = trainDataMatrix/255;
testDataMatrix = 1-testDataMatrix;
testDataMatrix = 254*testDataMatrix;
testDataMatrix = 1+testDataMatrix;
testDataMatrix = testDataMatrix/255;

clear testLabel;
clear trainLabel;

%% ex1 Train a 6c-2s-12c-2s Convolutional neural network 
%will run 1 epoch in about 200 second and get around 11% error. 
%With 100 epochs you'll get around 1.2% error
rand('state',0)		%random seed
cnn.layers = {
    struct('type', 'i') %input layer
    struct('type', 'c', 'outputmaps', 6, 'kernelsize', 5) %convolution layer
    struct('type', 's', 'scale', 2) %sub sampling layer
    struct('type', 'c', 'outputmaps', 12, 'kernelsize', 5) %convolution layer
    struct('type', 's', 'scale', 2) %subsampling layer
    
    %struct('type', 'c', 'outputmaps', 12, 'kernelsize', 5) %convolution layer
    %struct('type', 's', 'scale', 1) %subsampling layer
};
cnn = cnnsetup(cnn, trainDataMatrix, trainDataLabels);

opts.alpha = 1;
opts.batchsize = 2;           %50;  310 is gcd 2480,930
opts.numepochs = 3;

cnn = cnntrain(cnn, trainDataMatrix, trainDataLabels, opts);

[er,bad,good,h,cnn_test] = cnntest(cnn, testDataMatrix, testDataLabels);

%plot mean squared error
%figure; plot(cnn.rL);
display(['Error =' num2str(er) ' bad=' num2str(bad)]);
display(['good =' num2str(good)]);
display(['h =' num2str(h)]);
save(['cnn_' num2str(opts.numepochs) 'epochs_' num2str(numel(cnn.layers)) 'layers' thin],'cnn');
%last=net_test.fv;

%assert(er<0.12, 'Too big error');

display('code ran !');