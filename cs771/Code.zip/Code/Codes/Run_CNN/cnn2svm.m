%Takes the value of features at second last layer of CNN and gives the data in format for svm (one-all multiclass)
cd('D:\study\cs771\Project\codefinal');
addpath(genpath('./DeepLearnToolbox-master'));
clear all
clc

thin = '_normalNew';         %'thin' for thin data ; '_normal' for normal data
load(['cnn_3epochs_5layers' thin]);
display(['Loaded cnn.mat layers=' num2str(numel(cnn.layers)) thin]);

%code from englishHnd_CNN.m ==============================================
%sampleI = imread('dataset/Sample001/img001-001.png');
%imageRows = size(sampleI,1); imageCols = size(sampleI,2);
totalClasses = 62;

load(['dataMatrix' thin '/trainDataLabels.mat']);        %2480 x 1
load(['dataMatrix' thin '/trainDataMatrix.mat']);        %2480 x 2304
load(['dataMatrix' thin '/testDataLabels.mat']);         %930 x 1
load(['dataMatrix' thin '/testDataMatrix.mat']);         %930 x 2304
%imshow(reshape(dataMatrix(40,:),48,48));

%transform labels to bitvector
trainLabel = zeros(size(trainDataLabels,1),totalClasses);
for i=1:size(trainDataLabels,1)
    trainLabel(i,trainDataLabels(i))=1;
end
testLabel = zeros(size(testDataLabels,1),totalClasses);
for i=1:size(testDataLabels,1)
    testLabel(i,testDataLabels(i))=1;
end
clear testDataLabels;
clear trainDataLabels;

%RESHAPE(X,M,N..) returns the M-by-N-by-.. matrix whose elements are taken column-wise from X.  An error results if X does not have M*N elements.
trainDataMatrix = double(reshape(trainDataMatrix',48,48,2728));         %2480 Old,  2728 new
trainDataLabels = double(trainLabel');
testDataMatrix = double(reshape(testDataMatrix',48,48,682));            %930 Old, 682 new
testDataLabels = double(testLabel');

%transform dataMatrix
trainDataMatrix = 1-trainDataMatrix;
trainDataMatrix = 254*trainDataMatrix;
trainDataMatrix = 1+trainDataMatrix;
trainDataMatrix = trainDataMatrix/255;
testDataMatrix = 1-testDataMatrix;
testDataMatrix = 254*testDataMatrix;
testDataMatrix = 1+testDataMatrix;
testDataMatrix = testDataMatrix/255;

clear testLabel;
clear trainLabel;
%=========================================================================

%Performance of CNN ======================================================
[er] = cnntest(cnn, testDataMatrix, testDataLabels);
display(['Error of  CNN on test data (%) = ' num2str(er*100)]);
[er] = cnntest(cnn, trainDataMatrix, trainDataLabels);
display(['Error of  CNN on train data (%) = ' num2str(er*100)]);
%=========================================================================

%Save data for SVM format ================================================
%testDataSVM ====
[~,~,~,~,cnnTemp] = cnntest(cnn, testDataMatrix, testDataLabels);
testDataSVM = cnnTemp.fv;
testDataSVM = testDataSVM';
%trainDataSVM ====
[~,~,~,~,cnnTemp] = cnntest(cnn, trainDataMatrix, trainDataLabels);
trainDataSVM = cnnTemp.fv;
trainDataSVM = trainDataSVM';
%testLabelsSVM ====
load(['dataMatrix' thin '/testDataLabels.mat']);
testLabelsSVM = testDataLabels;
%trainLabelsSVM ====
load(['dataMatrix' thin '/trainDataLabels.mat']);
trainLabelsSVM = trainDataLabels;
%save ====
save('dataMatrix_cnn2svm/testDataSVM.mat','testDataSVM');
save('dataMatrix_cnn2svm/trainDataSVM.mat','trainDataSVM');
save('dataMatrix_cnn2svm/testLabelsSVM.mat','testLabelsSVM');
save('dataMatrix_cnn2svm/trainLabelsSVM.mat','trainLabelsSVM');
testData = [testDataSVM testLabelsSVM];
trainData = [trainDataSVM trainLabelsSVM];
combinedData = [trainData ; testData];
header=1:size(combinedData,2);
combinedData = [header ; combinedData];
csvwrite('dataMatrix_cnn2svm/testData.csv',testData);
csvwrite('dataMatrix_cnn2svm/trainData.csv',trainData);
csvwrite('dataMatrix_cnn2svm/combinedData.csv',combinedData);
%=========================================================================


