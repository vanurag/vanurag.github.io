clear all; close all; clc;

cd('D:\study\cs771\Project\codefinal');
addpath(genpath('./libsvm-3.17'));

load('dataMatrix_cnn2svm/trainDataSVM.mat')
load('dataMatrix_cnn2svm/trainLabelsSVM.mat')
load('dataMatrix_cnn2svm/testDataSVM.mat')
load('dataMatrix_cnn2svm/testLabelsSVM.mat')

%cross-validation on complete data
completeDataSVM = [trainDataSVM;testDataSVM];
completeLabelsSVM = [trainLabelsSVM;testLabelsSVM];
modelCrossValidate = svmtrain(completeLabelsSVM,completeDataSVM,'-g 0.04 -v 9');

%test-train data
modelTrain = svmtrain(trainLabelsSVM,trainDataSVM,'-g 0.04 -c 1.0');
[predicted_label, accuracy, prob_estimates] = svmpredict(testLabelsSVM, testDataSVM, modelTrain);
