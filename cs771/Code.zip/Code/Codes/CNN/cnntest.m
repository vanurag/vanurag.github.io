function [er, bad, good, h,net] = cnntest(net, x, y)
    %  feedforward
    net = cnnff(net, x);
    [~, h] = max(net.o);			%~ means ignore first argument
    [~, a] = max(y);
    bad = find(h ~= a);
    good = find(h == a);

    er = numel(bad) / size(y, 2);
end
