clc;
close all;
for i=1:62
    for j=1:55
        if(j==1)
            mkdir(cat(2,'D:\study\cs771\Project\Data_input_thin\English\Hnd\Img\Sample0',sprintf('%02d',i)));
        end
        I = imread(cat(2,'D:\study\cs771\Project\Data_input\English\Hnd\Img\Sample0',sprintf('%02d',i),'\img0',sprintf('%02d',i),'-0',sprintf('%02d',j),'.png'));
        x=bwmorph(~I,'thin',inf);
        x=bwmorph(x,'dilate');
        %imshow(~x);
        imwrite(~x,cat(2,'D:\study\cs771\Project\Data_input_thin\English\Hnd\Img\Sample0',sprintf('%02d',i),'\img0',sprintf('%02d',i),'-0',sprintf('%02d',j),'.png'));
        %pause;
        %imshow(bwmorph(x,'erode'));
    end
end