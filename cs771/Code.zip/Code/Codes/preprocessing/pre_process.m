close all;
clear all;
for i=1:62
    for j=1:55
        if(j==1)
            mkdir(cat(2,'D:\study\cs771\Project\Data_input\English\Hnd\Img\Sample0',sprintf('%02d',i)));
        end
        img = im2bw(imread(cat(2,'D:\study\cs771\Project\Data\English\Hnd\Img\Sample0',sprintf('%02d',i),'\img0',sprintf('%02d',i),'-0',sprintf('%02d',j),'.png')));
        size_x = size(img,1);
        size_y = size(img,2);
        f = 1-img;
        m00 = sum(sum(f));
        m01 = sum(sum(repmat([1:size_y],size_x,1).*f));
        m10 = sum(sum(repmat([1:size_x]',1,size_y).*f));
        c_x = m10/m00;
        c_y = m01/m00;
        u02 = sum(sum(repmat([1-c_y:size_y-c_y].^2,size_x,1).*f));
        u20 = sum(sum(repmat([1-c_x:size_x-c_x]'.^2,1,size_y).*f));
        u02 = u02/m00;
        u20 = u20/m00;
        R = img(max(1,c_x-2*sqrt(u20)):min(size_x,c_x+2*sqrt(u20)),max(1,c_y-2*sqrt(u02)):min(size_y,c_y+2*sqrt(u02)));
        input_img = ones(48,48);
        if(size(R,1)<=size(R,2))
            tmp = imresize(R, [NaN 48]);		%only one dimension given.
            diff = int8((48-size(tmp,1))/2);
            if(diff~=0)
                input_img = cat(1,ones([diff 48]),tmp,ones([48-size(tmp,1)-diff 48]));
            else
                input_img = tmp;
            end
        else
            tmp = imresize(R, [48 NaN]);
            diff = int8((48-size(tmp,2))/2);
            if(diff~=0)
                input_img = cat(2,ones([48 diff]),tmp,ones([48 48-size(tmp,2)-diff]));
            else
                input_img = tmp;
            end
        end
        imwrite(input_img,cat(2,'D:\study\cs771\Project\Data_input\English\Hnd\Img\Sample0',sprintf('%02d',i),'\img0',sprintf('%02d',i),'-0',sprintf('%02d',j),'.png'));
    end
end
