close all;
clear all;
clc;
trainDataMatrix = [];
trainDataLabels = [];
testSamples=11;
for i=1:62
    for j=1:55
        I = imread(cat(2,'../dataset_24x24/Sample0',sprintf('%02d',i),'/img0',sprintf('%02d',i),'-0',sprintf('%02d',j),'.png'));
        I = im2bw(I,0.5);
        if(i==1 && j==1)  %initialize train
            testDataMatrix = I(:)';
            testDataLabels = [1];
        elseif(i==1 && j==testSamples+1)
            trainDataMatrix = I(:)';
            trainDataLabels = [1];
        elseif(j<=testSamples)
            testDataMatrix = cat(1,testDataMatrix,I(:)');
            testDataLabels = cat(1,testDataLabels,i);
        else
            trainDataMatrix = cat(1,trainDataMatrix,I(:)');
            trainDataLabels = cat(1,trainDataLabels,i);
        end
    end
end
save('../dataMatrix_normalNew24x24/trainDataMatrix.mat','trainDataMatrix');
save('../dataMatrix_normalNew24x24/trainDataLabels.mat','trainDataLabels');
save('../dataMatrix_normalNew24x24/testDataMatrix.mat','testDataMatrix');
save('../dataMatrix_normalNew24x24/testDataLabels.mat','testDataLabels');