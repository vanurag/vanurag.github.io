Machine Learning Project
Recognition of Handwritten Characters
Group-6

Data Used
EnglishHnd_62classes
=====================================================================================

Libraries and Toolbox Used

1)	DeepLearn ToolBox (Matlab )
Used for Convolutional Neural Network
(http://www.mathworks.com/matlabcentral/fileexchange/38310-deep-learning-toolbox)

2)	LibSVM
SVM Implementation
=====================================================================================

Directories

1)	Pre processing :
a.	Codes/preprocessing/pre_process.m
b.	Codes/preprocessing/generate_matrix.m

2)	CNN
a.	Code/Run_CNN/ englishHnd_CNN.m

3)	CNN to SVM
a.	Codes/Run_CNN/cnn2svm.m

4)	SVM
a.	Codes/libsvm-3.17/matlab/svm.m

5)	Generate plots
a.	Codes/plot_graphs.m

6)	Preprocessed Input Data
a.	Codes/data/...
=====================================================================================

Thank You!
