% variable precision
function [bla] = vp(x,p)
bla = round(x*(10^p))/(10^p);
end