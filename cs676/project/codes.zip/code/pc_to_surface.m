number_of_points = 150000;      %  builds a surface from these many points in the point cloud
option = 1;     %option 1: builds surface of entire scene
                %option 2: builds surface of confined space (useful for building surfaces of specific objects)
pc = pc_base(:,1:number_of_points);
x_min = vp(min(pc(1,:)),2);x_max = vp(max(pc(1,:)),2);
y_min = vp(min(pc(2,:)),2);y_max = vp(max(pc(2,:)),2);
z_min = vp(min(pc(3,:)),2);z_max = vp(max(pc(3,:)),2);
switch option
    case 1
        x_lim = [x_min,x_max];
        y_lim = [y_min,y_max];
        z_lim = [z_min,z_max];
    case 2      % set the limits. all values in metres and relative to the camera coordinate system
        x_lim = [-0.8,0.8];
        y_lim = [-0.8,0.8];
        z_lim = [z_min,1.5];
end
%%
[X,Y,Z] = meshgrid(x_lim(1):0.01:x_lim(2),y_lim(1):0.01:y_lim(2),z_lim(1):0.01:z_lim(2));
% V = ones(round((x_max-x_min)/0.01 + 1),round((y_max-y_min)/0.01 + 1),round((z_max-z_min)/0.01 + 1));
V = zeros(size(X));
%%
pc_x = round((vp(pc(1,:),2)-x_lim(1))/0.01 + 1);
pc_y = round((vp(pc(2,:),2)-y_lim(1))/0.01 + 1);
pc_z = round((vp(pc(3,:),2)-z_lim(1))/0.01 + 1);

R = zeros(size(X));G = zeros(size(X));B = zeros(size(X));

for i=1:size(pc_x,2)
    if x_lim(1) <= pc(1,i) && pc(1,i) <= x_lim(2) && y_lim(1) <= pc(2,i) && pc(2,i) <= y_lim(2) && z_lim(1) <= pc(3,i) && pc(3,i) <= z_lim(2)
        V(pc_y(i),pc_x(i),pc_z(i)) = 1;
        R(pc_y(i),pc_x(i),pc_z(i)) = pc_rgb(1,i);
        G(pc_y(i),pc_x(i),pc_z(i)) = pc_rgb(2,i);
        B(pc_y(i),pc_x(i),pc_z(i)) = pc_rgb(3,i);
    end
end

p = patch(isosurface(X,Y,Z,V,0.8));
isonormals(X,Y,Z,V,p);
% isocolors(X,Y,Z,smooth3(R,'gaussian',5),smooth3(G,'gaussian',5),smooth3(B,'gaussian',5),p);
isocolors(X,Y,Z,R,G,B,p);

vertices = get(p,'Vertices');
faces = get(p,'Faces');
colour = get(p,'FaceVertexCData');
normals = get(p,'VertexNormals');

R_min = min(colour(:,1));
G_min = min(colour(:,2));
B_min = min(colour(:,3));
R_max = max(colour(:,1));
G_max = max(colour(:,2));
B_max = max(colour(:,3));

colour = imadjust(reshape(colour,[size(colour,1),1,3]),[R_min,G_min,B_min;R_max,G_max,B_max],[0,0,0;1,1,1]);
colour = reshape(colour,size(colour,1),3);
set(p,'FaceVertexCData',colour)

f = fopen('ascii.ply','w'); 
fclose(f);
f = fopen('ascii.ply','a'); 
fprintf(f,'%s\n%s\n','ply','format ascii 1.0');
fprintf(f,'%s\n','comment made by Anurag and Sudhanshu');
fprintf(f,'%s %s\n','element vertex',num2str(size(vertices,1)));
fprintf(f,'%s\n%s\n%s\n','property float x','property float y','property float z');
fprintf(f,'%s\n%s\n%s\n','property float nx','property float ny','property float nz');
fprintf(f,'%s\n%s\n%s\n','property uint8 red','property uint8 green','property uint8 blue');
fprintf(f,'%s %s\n','element face',num2str(size(faces,1)));
fprintf(f,'%s\n','property list uchar int vertex_index');
fprintf(f,'%s\n','end_header');
for i=1:size(vertices,1)
    fprintf(f,'%f %f %f ',vertices(i,1),vertices(i,2),vertices(i,3));
    fprintf(f,'%f %f %f ',normals(i,1),normals(i,2),normals(i,3));
    fprintf(f,'%u %u %u\n',floor(255*colour(i,1)),floor(255*colour(i,2)),floor(255*colour(i,3)));
end

for i=1:size(faces,1)
    fprintf(f,'%c %d %d %d\n','3',faces(i,1)-1,faces(i,2)-1,faces(i,3)-1);
end
fclose(f);

set(p,'FaceColor','interp','EdgeColor','interp');
daspect([1,1,1])
view([15,-85])
% view([5,-49])
axis tight
grid off
% camlight 
lighting gouraud