Unzip the contents of code.zip into current workspace in MatLab

a) Datasets:
	Each dataset has to contain,
		1) RGB images in the folder named 'rgb'
		2) Depth images (uint-16) in the folder named 'depth'
		3) text file 'rgb.txt' containing timestamps and path to the rgb images
		4) text file 'depth.txt' containing timestamps and path to the depth images
		5) text file 'groundtruth.txt' containing groundtruth data
	Refer: http://vision.in.tum.de/data/datasets/rgbd-dataset to download such datasets. Unzip the contents into the MatLab's working directory

b) For Trajectory:
	1) Run convert.m to get an estimated trajectory from depth data
	   convert.m takes a long time to run on all the depth images so we have placed a precomputed trajectory in rgbd.txt
	2) Run trajectory.m to visualize the trajectory and compare it with the groundtruth trajectory
	   It by default uses rgbd.txt and groundtruth of freiburg1_floor sequence dataset from the website mentioned above
	
c) For Surface:
	1) Run grouping_pc to transform all the point clouds to a common coordinate system and store their corresponding colour values
	2) Run pc_to_surface to get a surface reconstruction from point cloud. It outputs an ascii.ply file which has to be converted to 
	   binary format before being able to visualize in MeshLab

d) Ascii.ply to binay.ply:
	In a Linux environment, install the libply library by doing the following :
	1) Download the source distribution
	2) Unpack the archive (tar xzf ply-0.1.tar.gz)
	3) Move into the directory (cd ply-0.1/)
	4) Configure the package (./configure --prefix=/home/ares)
	5) Compile the programs and libraries (make)
	6) Install the programs and libraries (make install)
	7) Clean the package (make clean).

	Note1 : In order to locate the locate the dynamic libraries, update the dynamic library search path of the linker (export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/lib:) If libply was installed system-wide (./configure withouth --prefix=/home/ares), then reconfigure the dynamic linker run time bindings (ldconfig). 

	Note2 : gcc/g++ may give some undefined macro errors while compiling the library. In that case, just manually define the variable/marcro to the desired/expected value. In the project, the code in the sub-directory "ply-0.1/tools/" was compiled and used. Specifically, the ply2ply file was compiled and executed repeatedly to convert a ascii/text file in ply format to a binary/hex file in ply format.

	To execute ply2ply:
	$> ply2ply [OPTION] [INFILE] [OUTFILE]
	eg :
	$> ply2ply --format=binary_big_endian inputfile.ply outputfile.ply
	The above command will convert the inputfile.ply to outputfile.ply with outputfile.ply being in binary_big_endian format

	(Libply does not depend on any external libraries, except Boost, and requires <tr1/cstdint>, <tr1/functional>, <tr1/memory>, <tr1/tuple>. Libply was developed with gcc version 4.2.0. To uninstall libply, move into the directory (cd ply-0.1/), uninstall the programs and libraries (make uninstall), move out of the directory (cd ..), remove the directory (rm -r ply-0.1/), and remove the source distribution (rm ply-0.1.tar.gz). )

	Source : http://people.cs.kuleuven.be/~ares.lagae/libply/
	
e) Two example binary.ply files are also present. You can open them in MeshLab.
	'office_binary.ply' - Office desk. Laptop, keyboard, mouse, book etc. can be seen
	'plant._binary.ply' - dense 3D model of a flower pot. contains around 20 million points and takes time to generate