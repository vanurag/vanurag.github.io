close all
clear all
f = fopen('groundtruth2.txt');
f2 = fopen('rgbd.txt');

start = fscanf(f,'%c',1);
while start == '#'
    fgets(f);
    start = fscanf(f,'%c',1);
end
fseek(f,-1,'cof');
C = textscan(f,'%s %f %f %f %f %f %f %f');
fclose(f);
for i=1:size(C{1},1)
    C{1,9}(i) = str2double(C{1,1}{i,1}(9:end));
end

start = fscanf(f2,'%c',1);
while start == '#'
    fgets(f2);
    start = fscanf(f2,'%c',1);
end
fseek(f2,-1,'cof');
C2 = textscan(f2,'%s %f %f %f %f %f %f %f');
fclose(f2);
for i=1:size(C2{1},1)
    C2{1,9}(i) = str2double(C2{1,1}{i,1}(9:end));
end

index_large = 1;
prev = 1000;
for index_small=1:size(C2{1},1)
    while abs(C{1,9}(index_large) - C2{1,9}(index_small)) < prev
        prev = abs(C{1,9}(index_large) - C2{1,9}(index_small));
        match(index_small) = index_large;
        index_large = index_large + 1;
    end
    prev = 1000;
end
%%

Global = eye(3);
for i=1:size(match,2)
    t = [C{1,2}(match(i)) C{1,3}(match(i)) C{1,4}(match(i))];
    q = [C{1,5}(match(i)) C{1,6}(match(i)) C{1,7}(match(i)) C{1,8}(match(i))];
    R = [q(1)^2 + q(2)^2 - q(3)^2 - q(4)^2, 2*(q(2)*q(3) - q(1)*q(4)), 2*(q(2)*q(4) + q(1)*q(3));...
         2*(q(2)*q(3) + q(1)*q(4)), q(1)^2 - q(2)^2 + q(3)^2 - q(4)^2, 2*(q(3)*q(4) - q(1)*q(2));...
         2*(q(2)*q(4) - q(1)*q(3)), 2*(q(3)*q(4) + q(1)*q(2)), q(1)^2 - q(2)^2 - q(3)^2 + q(4)^2];
    
    Cam = R*Global;
    
    t2 = [C2{1,2}(i) C2{1,3}(i) C2{1,4}(i)];
    q = [C2{1,5}(i) C2{1,6}(i) C2{1,7}(i) C2{1,8}(i)];
    R = [q(1)^2 + q(2)^2 - q(3)^2 - q(4)^2, 2*(q(2)*q(3) - q(1)*q(4)), 2*(q(2)*q(4) + q(1)*q(3));...
         2*(q(2)*q(3) + q(1)*q(4)), q(1)^2 - q(2)^2 + q(3)^2 - q(4)^2, 2*(q(3)*q(4) - q(1)*q(2));...
         2*(q(2)*q(4) - q(1)*q(3)), 2*(q(3)*q(4) + q(1)*q(2)), q(1)^2 - q(2)^2 - q(3)^2 + q(4)^2];
     
    Cam2 = R*Global;
    
    quiver3([0 0 0],[0 0 0],[0 0 0],Global(:,1)',Global(:,2)',Global(:,3)',0.6,'LineWidth',2)
    
    axis equal
    xlim([-0.5,2])
    ylim([-1.5,1])
    zlim([0,2])
    view([130,30])
%     view([133,16])
    grid off
    hold on
    quiver3([t(1) t(1) t(1)],[t(2) t(2) t(2)],[t(3) t(3) t(3)],Cam(:,1)',Cam(:,2)',Cam(:,3)',0.2,'LineWidth',2)
    quiver3([t2(1) t2(1) t2(1)],[t2(2) t2(2) t2(2)],[t2(3) t2(3) t2(3)],Cam2(:,1)',Cam2(:,2)',Cam2(:,3)',0.2,'LineWidth',2)
    legend('Global coordiante system','Ground Truth','Estimated Trajectory','Location','North')
    hold off
    M(i) = getframe();
end
movie2avi(M, 'anim.avi','quality',100,'fps',30,'compression','Cinepak');
