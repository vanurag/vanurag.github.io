clear all
close all

tic
N = 10;     % trajectory of camera through the first N frames is estimated
%%  Aligning timestamps of groundtruth and depth images

f = fopen('groundtruth.txt');
f2 = fopen('depth.txt');

start = fscanf(f,'%c',1);
while start == '#'
    fgets(f);
    start = fscanf(f,'%c',1);
end
fseek(f,-1,'cof');
C = textscan(f,'%s %f %f %f %f %f %f %f');
fclose(f);
for i=1:size(C{1},1)
    C{1,9}(i) = str2double(C{1,1}{i,1}(9:end));
end

start = fscanf(f2,'%c',1);
while start == '#'
    fgets(f2);
    start = fscanf(f2,'%c',1);
end
fseek(f2,-1,'cof');
C2 = textscan(f2,'%s %s');
fclose(f2);
for i=1:size(C2{1},1)
    C2{1,3}(i) = str2double(C2{1,1}{i,1}(9:end));
end

index_large = 1;
prev = 1000;
for index_small=1:size(C2{1},1)
    while abs(C{1,9}(index_large) - C2{1,3}(index_small)) < prev
        prev = abs(C{1,9}(index_large) - C2{1,3}(index_small));
        match(index_small) = index_large;
        index_large = index_large + 1;
    end
    prev = 1000;
end

TT_prev = [C{1,2}(match(1));C{1,3}(match(1));C{1,4}(match(1))];
q = [C{1,5}(match(1)) C{1,6}(match(1)) C{1,7}(match(1)) C{1,8}(match(1))];
TR_prev = [q(1)^2 + q(2)^2 - q(3)^2 - q(4)^2, 2*(q(2)*q(3) - q(1)*q(4)), 2*(q(2)*q(4) + q(1)*q(3));...
     2*(q(2)*q(3) + q(1)*q(4)), q(1)^2 - q(2)^2 + q(3)^2 - q(4)^2, 2*(q(3)*q(4) - q(1)*q(2));...
     2*(q(2)*q(4) - q(1)*q(3)), 2*(q(3)*q(4) + q(1)*q(2)), q(1)^2 - q(2)^2 - q(3)^2 + q(4)^2];

f3 = fopen('estimated_trajectory.txt','w'); 
fclose(f3);
f3 = fopen('estimated_trajectory.txt','a'); 
q_square = 0.25*[1 1 1 1;1 -1 -1 1;-1 1 -1 1;-1 -1 1 1]*[TR_prev(1,1);TR_prev(2,2);TR_prev(3,3);1];
q = [1;sign(TR_prev(3,2) - TR_prev(2,3));sign(TR_prev(1,3) - TR_prev(3,1));sign(TR_prev(2,1) - TR_prev(1,2))].*sqrt(q_square);

fprintf(f3,'%s %f %f %f %f %f %f %f\n',C2{1,1}{1,1},TT_prev(1),TT_prev(2),TT_prev(3),q(1),q(2),q(3),q(4));

pc_g = [];

for i=1:10%size(match,2)-1
    image1 = imread(C2{1,2}{i,1});
    image2 = imread(C2{1,2}{i+1,1});

    img1_5k = cast(image1,'double');
    img1_5k = img1_5k/5000;

    img2_5k = cast(image2,'double');
    img2_5k = img2_5k/5000;

    row1 = repmat((1:480)',[1,640]);
    col1 = repmat((1:640),[480,1]);
    bin1 = img1_5k ~= 0;
    pc1 = cat(2,col1(bin1),row1(bin1),img1_5k(bin1))';    
    
    row2 = repmat((1:480)',[1,640]);
    col2 = repmat((1:640),[480,1]);
    bin2 = img2_5k ~= 0;
    pc2 = cat(2,col2(bin2),row2(bin2),img2_5k(bin2))';


    fy = 525;
    fx = 525;
    cx = 319.5;
    cy = 239.5;
    ds = 1;

    pc1 = datasample(pc1,5000,2,'Replace',false);
    pc1(1,:) = ((pc1(1,:) - repmat(cx,[1,size(pc1,2)])).*pc1(3,:))/fx;
    pc1(2,:) = ((pc1(2,:) - repmat(cy,[1,size(pc1,2)])).*pc1(3,:))/fy;
    
%     TR_prev*pc1 + repmat(TT_prev,[1,size(pc1,2)])
    pc_g = cat(2,pc_g,TR_prev*pc1 + repmat(TT_prev,[1,size(pc1,2)]));

    pc2 = datasample(pc2,5000,2,'Replace',false);
    pc2(1,:) = ((pc2(1,:) - repmat(cx,[1,size(pc2,2)])).*pc2(3,:))/fx;
    pc2(2,:) = ((pc2(2,:) - repmat(cy,[1,size(pc2,2)])).*pc2(3,:))/fy;

%     scatter3(pc1(1,:),pc1(2,:),pc1(3,:),1)
%     view([0,-90])
%     figure
%     scatter3(pc2(1,:),pc2(2,:),pc2(3,:),1)
%     view([0,-90])

    [TR, TT] = icp(pc2,pc1);
    
    TR_prev = TR_prev*(TR');
    TT_prev = TT_prev - TR_prev*TT;
    
%     TT_prev = [C{1,2}(match(i));C{1,3}(match(i));C{1,4}(match(i))];
%     q = [C{1,5}(match(i)) C{1,6}(match(i)) C{1,7}(match(i)) C{1,8}(match(i))];
%     TR_prev = [q(1)^2 + q(2)^2 - q(3)^2 - q(4)^2, 2*(q(2)*q(3) - q(1)*q(4)), 2*(q(2)*q(4) + q(1)*q(3));...
%                2*(q(2)*q(3) + q(1)*q(4)), q(1)^2 - q(2)^2 + q(3)^2 - q(4)^2, 2*(q(3)*q(4) - q(1)*q(2));...
%                2*(q(2)*q(4) - q(1)*q(3)), 2*(q(3)*q(4) + q(1)*q(2)), q(1)^2 - q(2)^2 - q(3)^2 + q(4)^2];
    
    q_square = 0.25*[1 1 1 1;1 -1 -1 1;-1 1 -1 1;-1 -1 1 1]*[TR_prev(1,1);TR_prev(2,2);TR_prev(3,3);1];
    q = [1;sign(TR_prev(3,2) - TR_prev(2,3));sign(TR_prev(1,3) - TR_prev(3,1));sign(TR_prev(2,1) - TR_prev(1,2))].*sqrt(q_square);
    
    fprintf(f3,'%s %f %f %f %f %f %f %f\n',C2{1,1}{i+1,1},TT_prev(1),TT_prev(2),TT_prev(3),q(1),q(2),q(3),q(4));
end
fclose(f3);
% scatter3(pc_g(1,:),pc_g(2,:),pc_g(3,:),1)
% view([0,-90])
toc