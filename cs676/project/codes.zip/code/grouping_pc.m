clear all
close all

tic
number_of_images = 20;         %set this parameter as per your inerest
%%  Aligning timestamps of groundtruth and depth images

f = fopen('groundtruth.txt');
f2 = fopen('depth.txt');
f3 = fopen('rgb.txt');

start = fscanf(f,'%c',1);
while start == '#'
    fgets(f);
    start = fscanf(f,'%c',1);
end
fseek(f,-1,'cof');
C = textscan(f,'%s %f %f %f %f %f %f %f');
fclose(f);
for i=1:size(C{1},1)
    C{1,9}(i) = str2double(C{1,1}{i,1}(9:end));
end

start = fscanf(f2,'%c',1);
while start == '#'
    fgets(f2);
    start = fscanf(f2,'%c',1);
end
fseek(f2,-1,'cof');
C2 = textscan(f2,'%s %s');
fclose(f2);
for i=1:size(C2{1},1)
    C2{1,3}(i) = str2double(C2{1,1}{i,1}(9:end));
end

start = fscanf(f3,'%c',1);
while start == '#'
    fgets(f3);
    start = fscanf(f3,'%c',1);
end
fseek(f3,-1,'cof');
C3 = textscan(f3,'%s %s');
fclose(f3);
for i=1:size(C3{1},1)
    C3{1,3}(i) = str2double(C3{1,1}{i,1}(9:end));
end

index_large = 1;
prev = 1000;
for index_small=1:size(C2{1},1)
    while index_large <= size(C{1,1},1) && abs(C{1,9}(index_large) - C2{1,3}(index_small)) < prev
        prev = abs(C{1,9}(index_large) - C2{1,3}(index_small));
        match1(index_small) = index_large;
        index_large = index_large + 1;
    end
    prev = 1000;
end
%%
index_large = 1;
prev = 1000;
for index_small=1:size(C2{1},1)
    while index_large <= size(C3{1,1},1) && abs(C3{1,3}(index_large) - C2{1,3}(index_small)) < prev
        prev = abs(C3{1,3}(index_large) - C2{1,3}(index_small));
        match2(index_small) = index_large;
        index_large = index_large + 1;
    end
    prev = 1000;
end
%%
TR_prev = eye(3);
TT_prev = 0;
pc_rgb = [];

for i=1:number_of_images
    image1 = imread(C2{1,2}{i,1});
    image2 = imread(C2{1,2}{i+1,1});
    if i==1
        RGB1 = imread(C3{1,2}{match2(i),1});
    end
    RGB2 = imread(C3{1,2}{match2(i+1),1});

    img1_5k = cast(image1,'double');
    img1_5k = img1_5k/5000;

    img2_5k = cast(image2,'double');
    img2_5k = img2_5k/5000;
    
    if i==1
        RGB1 = cast(RGB1,'double');
        RGB1 = RGB1/255;
        R1 = RGB1(:,:,1);
        G1 = RGB1(:,:,2);
        B1 = RGB1(:,:,3);
    end

    RGB2 = cast(RGB2,'double');
    RGB2 = RGB2/255;
    R2 = RGB2(:,:,1);
    G2 = RGB2(:,:,2);
    B2 = RGB2(:,:,3);
        
    row1 = repmat((1:480)',[1,640]);
    col1 = repmat((1:640),[480,1]);
    bin1 = img1_5k ~= 0;
    pc1 = cat(2,col1(bin1),row1(bin1),img1_5k(bin1))';
    if i==1
        pc_1_rgb_large = cat(2,R1(bin1),G1(bin1),B1(bin1))';
    end
    
    row2 = repmat((1:480)',[1,640]);
    col2 = repmat((1:640),[480,1]);
    bin2 = img2_5k ~= 0;
    pc2 = cat(2,col2(bin2),row2(bin2),img2_5k(bin2))';
    pc_2_rgb_large = cat(2,R2(bin2),G2(bin2),B2(bin2))';


    fy = 525;
    fx = 525;
    cx = 319.5;
    cy = 239.5;
    ds = 1;
    
    pc1(1,:) = ((pc1(1,:) - repmat(cx,[1,size(pc1,2)])).*pc1(3,:))/fx;
    pc1(2,:) = ((pc1(2,:) - repmat(cy,[1,size(pc1,2)])).*pc1(3,:))/fy;
    
    pc2(1,:) = ((pc2(1,:) - repmat(cx,[1,size(pc2,2)])).*pc2(3,:))/fx;
    pc2(2,:) = ((pc2(2,:) - repmat(cy,[1,size(pc2,2)])).*pc2(3,:))/fy;

    if i==1
        pc1_for_icp = datasample(pc1,1000,2,'Replace',false);
        dummy1 = datasample(cat(1,pc1,pc_1_rgb_large),size(pc1,2),2,'Replace',false);
        pc1_for_surface = dummy1(1:3,:);
%         pc1_for_surface = pc1;
        pc_rgb = dummy1(4:6,:);
%         pc_rgb = pc_1_rgb_large;
    else
        pc1_for_icp = datasample(pc1,1000,2,'Replace',false);
    end
    
    pc2_for_icp = datasample(pc2,1000,2,'Replace',false);
    dummy2 = datasample(cat(1,pc2,pc_2_rgb_large),size(pc2,2),2,'Replace',false);
    pc2_for_surface = dummy2(1:3,:);
%     pc2_for_surface = pc2;
    pc_rgb = cat(2,pc_rgb,dummy2(4:6,:));
%     pc_rgb = cat(2,pc_rgb,pc_2_rgb_large);


    if i == 1
        pc_base = pc1_for_surface;
    end
    
    [TR, TT] = icp(pc1_for_icp,pc2_for_icp);
    
    TR_prev = TR_prev * TR;
    TT_prev = TT_prev + TT;
    
    pc2_transformed = TR_prev*pc2_for_surface + repmat(TT_prev,[1,size(pc2_for_surface,2)]);
    pc_base = cat(2,pc_base,pc2_transformed);
end
% scatter3(pc_g(1,:),pc_g(2,:),pc_g(3,:),1)
% view([0,-90])
toc