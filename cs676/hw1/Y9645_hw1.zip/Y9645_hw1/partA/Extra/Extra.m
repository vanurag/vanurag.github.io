close all
clear all
alpha = 0.05;
k = 1;
mu = imread('../../../PETS2000/test0001.jpg');
mu = rgb2gray(mu);
mu = im2double(mu);
var = 10*ones(size(mu));
for t=2:150
    I_t = rgb2gray(imread(sprintf('../../../PETS2000/test%04d.jpg',t)));
    I_t = im2double(I_t);
    C_t = 255*((I_t - mu).^2 >= (var * k^2));
    background = 1-(C_t/255);
    foreground = 1 - background;
    mu = background .* ((1-alpha).*mu + alpha.*I_t) + foreground .* mu;
    var = background .* ((1-alpha).*var + alpha.*((I_t - mu).^2)) + foreground .* var;
end
imshow(C_t);
figure
%%
%Erosion
C_eroded = C_t;
m = 5;
for i=1:size(mu,1)
    for j=1:size(mu,2)
        if ceil(m/2)<=i && i<=size(mu,1)-(ceil(m/2)-1) && ceil(m/2)<=j && j<=size(mu,2)-(ceil(m/2)-1)
            nbd = C_t(i-2:i+2,j-2:j+2);
%             if C_t(i,j) ~= min(nbd(:))
                C_eroded(i,j) = min(nbd(:));
%             end
        else
            C_eroded(i,j) = 0;
        end
    end
end
imshow(C_eroded);
figure
%%
%Dialation
C_dialated = C_eroded;
m = 5;
for i=ceil(m/2):size(mu,1)-(ceil(m/2)-1)
    for j=ceil(m/2):size(mu,2)-(ceil(m/2)-1)
        nbd = C_eroded(i-2:i+2,j-2:j+2);
%             if C_t(i,j) ~= max(nbd(:))
            C_dialated(i,j) = max(nbd(:));
%             end
    end
end
imshow(C_dialated);
figure
%%
%Voting
C_voting = C_t;
m = 5;
neta = 0.6;
for i=1:size(mu,1)
    for j=1:size(mu,2)
        if ceil(m/2)<=i && i<=size(mu,1)-(ceil(m/2)-1) && ceil(m/2)<=j && j<=size(mu,2)-(ceil(m/2)-1)
            nbd = C_t(i-2:i+2,j-2:j+2);
            if sum(nbd(:)/255)>neta*(m^2) || sum(nbd(:)/255)<=(1-neta)*(m^2)
                C_voting(i,j) = 254*(sum(nbd(:)/255)>neta*(m^2)) + (1-(sum(nbd(:)/255)<=(1-neta)*(m^2)));
            end
        else
            C_voting(i,j) = 0;
        end
    end
end
imshow(C_voting);