close all
clear all
alpha = 0.1;t = 150;    %set these
mu = imread('../../PETS2000/test0001.jpg');
for i=2:t
    I_t = imread(sprintf('../../PETS2000/test%04d.jpg',i));
    mu = (1-alpha).*mu + alpha.*I_t;
end
imshow(round(mu));