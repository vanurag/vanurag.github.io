close all
clear all
Im = imread('test0130.jpg');
Im = imresize(Im, 0.5);
Im = im2double(Im);
k = 5;         %set this to number of clusters
K = [];
for i=1:k
    K = cat(1,K,reshape(Im(randi(288),randi(384),:),[1,3]));
end
%%
clustered_image = Im;
class = zeros(size(Im,1), size(Im,2));
epsilon = 10;
change = 100;
while change > epsilon
    for i=1:size(Im,1)
        for j=1:size(Im,2)
            D = [];
            for p=1:k
                D = cat(2, D, norm(reshape(Im(i,j,:),[1,3]) - K(p,:)));
            end
            [c,I] = min(D);
            clustered_image(i,j,:) = K(I,:);
            class(i, j) = I;
        end
    end
 
    change = 0;
    for i=1:k
        if nnz(class==i)~=0
            temp = reshape(sum(sum(repmat(class==i,[1,1,3]).*Im,1),2)/nnz(class==i),[1,3]);
            change = change + abs(K(i,:)-temp);
            K(i,:) = temp;
        end
    end
    
end
    
imshow(clustered_image)                