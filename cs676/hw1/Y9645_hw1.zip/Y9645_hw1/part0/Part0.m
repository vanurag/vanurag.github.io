close all
clear all
image = ones(400, 400);im = image;
C1 = [100, 300];C2 = [100, 100];C3 = [300, 100];C4 = [300, 300];
N1 = 100;N2 = 100;N3 = 50;N4 = 10;
radius = 100;
k = 4;
C = [C1;C2;C3;C4];
N = [N1;N2;N3;N4];
for i=1:size(C, 1)
    for j=1:N(i)
        r = radius * rand(1);
        theta = 2*pi*rand(1);
        x = C(i,1) + round(r*cos(theta));
        y = C(i,2) + round(r*sin(theta));
        image(x, y) = 0;
        im(x-1:x+1,y-1:y+1) = 0;
    end
end
imshow(im)
figure
%%

K = C;
for i=1:k
    K(i,:) = randi(400, [1, 2]);
end

clustered_image = 255 .* ones(400, 400, 3);
class = zeros(400, 400);
RGB = [255,0,0;255,255,0;0,0,255;0,0,0;0,128,0];
epsilon = 0;
change = 10;
while change > epsilon
    for i=1:400
        for j=1:400
            if image(i, j) == 0
                D = [];
                for p=1:k
                    D = cat(2, D, norm([i,j] - K(p,:)));
                end
                [c,I] = min(D);
                bla(1,1,:) = RGB(I,:);
                clustered_image(i-1:i+1,j-1:j+1,:) = repmat(bla,[3,3,1]);
                class(i, j) = I;
            end
        end
    end
 
    change = 0;
    for i=1:k
        [row, col] = find(class == i);
        change = change + abs(K(i,1)-round(mean(row))) + abs(K(i,2)-round(mean(col)));
        K(i,1) = round(mean(row));
        K(i,2) = round(mean(col));
    end
    
end
    
imshow(clustered_image)                