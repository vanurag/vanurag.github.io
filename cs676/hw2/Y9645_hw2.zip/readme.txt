Readme:

1) Unzip 'Y9645_hw2.zip' into MATLAB current directory(say, hw2)
2) Unzip [3] into the hw2 directory and name it by 'code'
3) Place Training data in hw2/data/train/CLASS_NAME and test data in hw2/data/test/CLASS_NAME, where CLASS_NAME is bengal_tiger/coffee_cup/giraffe.
4) Unzip 'results.zip' into hw2/
5) Move to the directory hw2/code/ and type 'setup' into Matlab command prompt.
6) Run hw2/partA/partA.m for partA and hw2/partA/partB.m for partB.

partA.m - computes feature histogram for 'bengal_toger.jpg', perform colour coding on the image wherein each word is represented by a colour. 
          It then computes dense SIFT features for all the training and test images in the database and saves the index of each SIFT which 
		  indiactes the closest vocab word to that SIFT. All the variables are stored in 'results' directory. 
		  For carrying on to partB results from partA have already been places in 'hw2/results' directory
		  You can run just first 2 cells of the code to save time. The SIFT features are already stored in 'results'.

partB.m	- Takes results from partA and trains SVMs for binary classification, multiclass classification. It even outputs various performance metrics as shown on the webpage.

* SVM library of MATLAB was causing problems in R2009 edition. I recommend using R2012.