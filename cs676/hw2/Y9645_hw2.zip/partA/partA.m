close all
clear all

%% Compute SIFT features for 'bengal_tiger.jpg'

im = cast(rgb2gray(imread('bengal_tiger.jpeg')),'single') ;
[frames, descrs] = vl_dsift(im, 'step', 1,'floatdescriptors') ;
imagesc(im) ; axis equal off ; hold on ;
figure

load('../data/vocab_1k.mat');
[index, dist] = vl_kdtreequery(kdtree, words, descrs);

colours = rand(3,size(words,2));
bl = zeros(size(im,1)-9,size(im,2)-9,3);
for i=1:size(frames,2)
    bl(frames(2,i)-4.5,frames(1,i)-4.5,:) = reshape(colours(:,index(i)),1,1,3);
%     plot(frames(1,i),size(im,2)-frames(2,i),'.','Color',colours(:,index(i))','MarkerSize',1,'LineWidth',1)
    hold on
end
imshow(bl)
figure
h = hist(index,1:1000);
bar(h)
title('Feature Histogram of bengal_tiger.jpg')
%%

figure
imagesc(imread('bengal_tiger.jpeg')); axis equal off ;hold on;
[c, i_max] = max(a);
plot(frames(1,(index==i_max)), frames(2,(index==i_max)), '.','MarkerSize',1,'MarkerEdgeColor','g');

%%  Computing SIFTS

listing = dir('../data/train/giraffe');     %place the directory whose SIFTs are to be computed
load('../data/vocab_1k.mat');
for i=3:size(listing,1)
    im = imread(['../data/train/giraffe/',listing(i,1).name]);    
    if size(im,3) > 1
        im = cast(rgb2gray(im),'single') ;
    else
        im = cast(im,'single') ;
    end
    
    [frames, descrs] = vl_dsift(im, 'step', 10,'floatdescriptors') ;
    [index, dist] = vl_kdtreequery(kdtree, words, descrs);
    save(['../results/train/giraffe/',listing(i,1).name(1:strfind(listing(i,1).name,'.JPEG')-1)],'index','dist');
end