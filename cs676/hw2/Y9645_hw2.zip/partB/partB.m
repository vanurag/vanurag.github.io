clear all
close all

tiger_accuracy = [];cup_accuracy = [];giraffe_accuracy = [];
P_tiger = [];R_tiger = [];F_tiger = [];
P_cup = [];R_cup = [];F_cup = [];
P_giraffe = [];R_giraffe = [];F_giraffe = [];
kernel = {'linear','quadratic','polynomial','mlp'};     %kernal choices
for choice=1:4
    class = cell(3,1);
    class{1,1} = 'bengal_tiger';class{2,1} = 'coffee_cup';class{3,1} = 'giraffe';

    %% Training Classifiers ..... 1 vs. rest and 1 vs. another

    Training = [];group = cell(0,0);
    for i=1:3
        path = ['../results/train/',class{i,1},'/'];
        listing = dir(path);

        for j=3:size(listing,1)
            load([path,listing(j,1).name],'index') ;
            [n,xout] = hist(index,1:1000);
            Training = cat(1,Training,n);
            group = cat(1,group,cell(1,1));
            group{end,1} = class{i,1};
        end
    end

    SVMStruct_tiger_vs_cup = svmtrain(Training(1:600,:),group(1:600,:),'kernel_function',kernel{1,choice});
    SVMStruct_tiger_vs_giraffe = svmtrain(cat(1,Training(1:300,:),Training(601:900,:)),cat(1,group(1:300,:),group(601:900,:)),'kernel_function',kernel{1,choice});
    SVMStruct_giraffe_vs_cup = svmtrain(Training(301:900,:),group(301:900,:),'kernel_function',kernel{1,choice});

    SVMStruct_tiger_vs_rest = svmtrain(Training(1:900,:),cat(1,group(1:300,:),repmat({'rest'},600,1)),'kernel_function',kernel{1,choice});
    SVMStruct_cup_vs_rest = svmtrain(Training(1:900,:),cat(1,repmat({'rest'},300,1),group(301:600,:),repmat({'rest'},300,1)),'kernel_function',kernel{1,choice});
    SVMStruct_giraffe_vs_rest = svmtrain(Training(1:900,:),cat(1,repmat({'rest'},600,1),group(601:900,:)),'kernel_function',kernel{1,choice});

    %% Classifying test images
    Sample = [];group = cell(0,0);
    for i=1:3
        path = ['../results/test/',class{i,1},'/'];
        listing = dir(path);

        for j=3:size(listing,1)
            load([path,listing(j,1).name],'index') ;
            [n,xout] = hist(index,1:1000);
            Sample = cat(1,Sample,n);
            group = cat(1,group,cell(1,1));
            group{end,1} = class{i,1};
        end
    end

    classified_tiger_vs_cup = svmclassify(SVMStruct_tiger_vs_cup,Sample(1:200,:));
    classified_tiger_vs_giraffe = svmclassify(SVMStruct_tiger_vs_giraffe,cat(1,Sample(1:100,:),Sample(201:300,:)));
    classified_giraffe_vs_cup = svmclassify(SVMStruct_giraffe_vs_cup,Sample(101:300,:));

    %% Multi-Class Classifier Accuracies

    tiger_accuracy = cat(2,tiger_accuracy,sum(strcmp('bengal_tiger',classified_tiger_vs_cup(1:100)) .* strcmp('bengal_tiger',classified_tiger_vs_giraffe(1:100))));
    cup_accuracy = cat(2,cup_accuracy,sum(strcmp('coffee_cup',classified_tiger_vs_cup(101:200)) .* strcmp('coffee_cup',classified_giraffe_vs_cup(1:100))));
    giraffe_accuracy = cat(2,giraffe_accuracy,sum(strcmp('giraffe',classified_tiger_vs_giraffe(101:200)) .* strcmp('giraffe',classified_giraffe_vs_cup(101:200))));

    %% Binary Classifiers Precision and Recall

    classified_tiger = svmclassify(SVMStruct_tiger_vs_rest,Sample(1:300,:));
    classified_cup = svmclassify(SVMStruct_cup_vs_rest,Sample(1:300,:));
    classified_giraffe = svmclassify(SVMStruct_giraffe_vs_rest,Sample(1:300,:));

    %tiger
    tp = sum(strcmp('bengal_tiger',classified_tiger(1:100,:)));
    fp = sum(strcmp('bengal_tiger',classified_tiger(101:300,:)));
    fn = sum(strcmp('rest',classified_tiger(1:100,:)));
    P_tiger = cat(2,P_tiger,tp/(tp+fp));   %precision
    R_tiger = cat(2,R_tiger,tp/(tp+fn));   %recall
    F_tiger = cat(2,F_tiger,2*P_tiger(end)*R_tiger(end)/(P_tiger(end) + R_tiger(end)));

    %cup
    tp = sum(strcmp('coffee_cup',classified_cup(101:200,:)));
    fp = sum(strcmp('coffee_cup',classified_cup(1:100,:))) + sum(strcmp('coffee_cup',classified_cup(201:300,:)));
    fn = sum(strcmp('rest',classified_cup(101:200,:)));
    P_cup = cat(2,P_cup,tp/(tp+fp));   %precision
    R_cup = cat(2,R_cup,tp/(tp+fn));   %recall
    F_cup = cat(2,F_cup,2*P_cup(end)*R_cup(end)/(P_cup(end) + R_cup(end)));

    %giraffe
    tp = sum(strcmp('giraffe',classified_giraffe(201:300,:)));
    fp = sum(strcmp('giraffe',classified_giraffe(1:200,:)));
    fn = sum(strcmp('rest',classified_giraffe(201:300,:)));
    P_giraffe = cat(2,P_giraffe,tp/(tp+fp));   %precision
    R_giraffe = cat(2,R_giraffe,tp/(tp+fn));   %recall
    F_giraffe = cat(2,F_giraffe,2*P_giraffe(end)*R_giraffe(end)/(P_giraffe(end) + R_giraffe(end)));
    
end

% Precision vs. kernel
plot(1:4,tiger_accuracy,'b',1:4,cup_accuracy,'r',1:4,giraffe_accuracy,'g','linewidth',2)
legend('tiger','coffee cup','giraffe','Location','North')
title('Accuracies vs. kernel choice')
set(gca, 'XTick',1:4, 'XTickLabel',{'linear' 'quadratic' 'polynomial' 'mlp'})
figure

plot(1:4,P_tiger,'b',1:4,P_cup,'r',1:4,P_giraffe,'g','linewidth',2)
legend('tiger','coffee cup','giraffe','Location','North')
title('Precision vs. kernel choice')
set(gca, 'XTick',1:4, 'XTickLabel',{'linear' 'quadratic' 'polynomial' 'mlp'})
figure

plot(1:4,R_tiger,'b',1:4,R_cup,'r',1:4,R_giraffe,'g','linewidth',2)
legend('tiger','coffee cup','giraffe','Location','North')
title('Recall vs. kernel choice')
set(gca, 'XTick',1:4, 'XTickLabel',{'linear' 'quadratic' 'polynomial' 'mlp'})
figure

plot(1:4,F_tiger,'b',1:4,F_cup,'r',1:4,F_giraffe,'g','linewidth',2)
legend('tiger','coffee cup','giraffe','Location','North')
title('F1-score vs. kernel choice')
set(gca, 'XTick',1:4, 'XTickLabel',{'linear' 'quadratic' 'polynomial' 'mlp'})
figure
%% P-R curves
lambda = (0.01:0.02:0.1)*1e-1;
Marker = ['b','r','y','k','g'];
for i=1:5
    w_t_vs_r = vl_pegasos(Training(1:900,:)', cast(cat(2,ones(1,300),-ones(1,600)),'int8'), lambda(i));

    [recall, precision, info] = vl_pr(cat(2,ones(1,100),-ones(1,200)), w_t_vs_r'*(Sample'));   %Tiger
    plot(recall,precision,'linewidth',2,'Color',Marker(i)) ;
    hold on
end
legend(['lambda = ',num2str(lambda(1))],['lambda = ',num2str(lambda(2))],...
    ['lambda = ',num2str(lambda(3))],['lambda = ',num2str(lambda(4))],...
    ['lambda = ',num2str(lambda(5))])
title('Precision-Recall curves for Tiger vs. rest')
figure
for i=1:5
    w_c_vs_r = vl_pegasos(Training(1:900,:)', cast(cat(2,-ones(1,300),ones(1,300),-ones(1,300)),'int8'), lambda(i));
    
    [recall, precision, info] = vl_pr(cat(2,-ones(1,100),ones(1,100),-ones(1,100)), w_c_vs_r'*(Sample'));   %cup
    plot(recall,precision,'linewidth',2,'Color',Marker(i)) ;
    hold on
end
legend(['lambda = ',num2str(lambda(1))],['lambda = ',num2str(lambda(2))],...
    ['lambda = ',num2str(lambda(3))],['lambda = ',num2str(lambda(4))],...
    ['lambda = ',num2str(lambda(5))])
title('Precision-Recall curves for Coffee cup vs. rest')
figure
for i=1:5
    w_g_vs_r = vl_pegasos(Training(1:900,:)', cast(cat(2,-ones(1,600),ones(1,300)),'int8'), lambda(i));

    [recall, precision, info] = vl_pr(cat(2,-ones(1,200),ones(1,100)), w_g_vs_r'*(Sample'));    %Giraffe
    plot(recall,precision,'linewidth',2,'Color',Marker(i)) ;
    hold on
end
legend(['lambda = ',num2str(lambda(1))],['lambda = ',num2str(lambda(2))],...
    ['lambda = ',num2str(lambda(3))],['lambda = ',num2str(lambda(4))],...
    ['lambda = ',num2str(lambda(5))])
title('Precision-Recall curves for Giraffe vs. rest')