Plain Text should be stored in "input.txt".(in HEX)
Encrypted output will be written by t_encrypt.v into "encrypted_text.txt".
Word Sequence will be written by keyexp.v into "word.txt".

All the files have values in HEX.