Encrypted Text will be written by t_encrypt.v into "encrypted_text.txt".(in HEX)
Decrypted output will be written by t_decrypt.v into "decrypted_text.txt".
Word Sequence will be written by t_keyexp.v into "word.txt".

All the files have values in HEX.