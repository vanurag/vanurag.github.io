key should be stored in "key.txt".(in HEX)
Expanded word sequence will be written by t_keyexp.v into "word.txt".

All the files have values stored in HEX.